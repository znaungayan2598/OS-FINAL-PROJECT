package com.ossimulator.model;

import java.util.List;

/** Stores CPU scheduling results and timing metrics. */
public record CpuResult(String algorithm, List<GanttSlice> gantt,
                        List<ProcessStats> processes, double averageWaiting,
                        double averageTurnaround, double utilization) {
}
