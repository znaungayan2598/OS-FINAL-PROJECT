package com.ossimulator.utils;

import javax.swing.*;
import java.awt.Component;
import java.awt.Cursor;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

/**
 * Runs a simulation on a SwingWorker background thread so very large inputs never freeze
 * the UI. Any failure is turned into a friendly dialog - nothing propagates as a crash.
 */
/** Runs simulations off the Swing event thread. */
public final class AsyncRunner {
    private AsyncRunner() {}

    public static <T> void run(Component parent, Callable<T> task, Consumer<T> onDone, JComponent... lock) {
        List<Boolean> states = new ArrayList<>();
        for (JComponent c : lock) {
            states.add(c.isEnabled());
            c.setEnabled(false);
        }
        if (parent != null) parent.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception {
                return task.call();
            }

            @Override protected void done() {
                try {
                    onDone.accept(get());
                } catch (ExecutionException ex) {
                    InputValidator.showFailure(parent, ex.getCause() == null ? ex : ex.getCause());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (RuntimeException t) {
                    InputValidator.showFailure(parent, t);
                } finally {
                    for (int i = 0; i < lock.length; i++) lock[i].setEnabled(states.get(i));
                    if (parent != null) parent.setCursor(Cursor.getDefaultCursor());
                }
            }
        }.execute();
    }
}
