package com.ossimulator.model;

/** Translation of one logical address. frame / physical are null when translation failed. */
public record PagingRow(long logical, long page, long offset, Long frame, Long physical,
                        String status, boolean ok) {
}
