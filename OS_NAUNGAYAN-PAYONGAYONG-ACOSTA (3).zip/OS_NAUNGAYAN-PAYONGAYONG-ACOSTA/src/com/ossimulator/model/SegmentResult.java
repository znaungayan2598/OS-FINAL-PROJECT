package com.ossimulator.model;

/** Outcome of translating one (segment, offset) query. base / limit / physical are null if unknown. */
public record SegmentResult(long segment, long offset, Long base, Long limit, Long physical,
                            boolean ok, String message) {
}
