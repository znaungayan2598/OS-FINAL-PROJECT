package com.ossimulator.model;

/** One head movement. kind is SERVICE (serves a request), EDGE (travel to a disk edge) or JUMP (wrap-around). */
public record DiskMove(long from, long to, long distance, String kind) {
    public static final String SERVICE = "SERVICE";
    public static final String EDGE = "EDGE";
    public static final String JUMP = "JUMP";
}
