package com.ossimulator;

import com.ossimulator.theme.ModernTheme;
import com.ossimulator.ui.panels.*;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/** Headless construction and preset-button smoke test for all module panels. */
public final class UiConstructionTest {
    private UiConstructionTest() {}
    public static void main(String... args) throws Exception {
        List<ModulePanelBase> panels = new ArrayList<>();
        SwingUtilities.invokeAndWait(() -> {
            ModernTheme.install();
            panels.addAll(List.of(new CpuPanel(), new BankerPanel(), new PagingPanel(),
                    new PageReplacementPanel(), new SegmentationPanel(), new FragmentationPanel(),
                    new DiskPanel(), new MultiprogrammingPanel()));
        });
        for (ModulePanelBase panel : panels) {
            AtomicReference<AbstractButton> run = new AtomicReference<>();
            SwingUtilities.invokeAndWait(() -> {
                click(panel, "Load Small Sample");
                run.set(clickRun(panel));
            });
            Thread.sleep(750);
            AtomicReference<String> output = new AtomicReference<>();
            SwingUtilities.invokeAndWait(() -> {
                output.set(findText(panel).getText());
                if (!run.get().isEnabled())
                    throw new IllegalStateException("Simulation did not finish for " + panel.getClass().getSimpleName());
            });
            if (output.get() == null || output.get().isBlank())
                throw new IllegalStateException("No simulation output for " + panel.getClass().getSimpleName());
            SwingUtilities.invokeAndWait(() -> {
                click(panel, "Load Large Dataset");
                click(panel, "Clear All");
            });
        }
        System.out.println("UI construction and preset tests passed.");
    }
    private static AbstractButton clickRun(Container root) {
        for (Component component : root.getComponents()) {
            if (component instanceof AbstractButton button
                    && (button.getText().startsWith("Run") || button.getText().equals("Translate Addresses"))) {
                button.doClick();
                return button;
            }
            if (component instanceof Container child) {
                try { return clickRun(child); }
                catch (IllegalStateException ignored) { }
            }
        }
        throw new IllegalStateException("Missing simulation button.");
    }
    private static void click(Container root, String text) {
        for (Component component : root.getComponents()) {
            if (component instanceof AbstractButton button && text.equals(button.getText())) {
                button.doClick();
                return;
            }
            if (component instanceof Container child) {
                try { click(child, text); return; }
                catch (IllegalStateException ignored) { }
            }
        }
        throw new IllegalStateException("Missing button: " + text);
    }
    private static JTextArea findText(Container root) {
        for (Component component : root.getComponents()) {
            if (component instanceof JTextArea area) return area;
            if (component instanceof Container child) {
                try { return findText(child); }
                catch (IllegalStateException ignored) { }
            }
        }
        throw new IllegalStateException("Missing output area.");
    }
}
