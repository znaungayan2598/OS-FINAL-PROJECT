package com.ossimulator.ui.components;

import com.ossimulator.model.GanttSlice;
import com.ossimulator.theme.ModernTheme;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Draws CPU process execution intervals. */
public final class GanttChartPanel extends JPanel {
    private List<GanttSlice> slices = List.of();
    public GanttChartPanel() { setBackground(ModernTheme.CARD); }
    public void setSlices(List<GanttSlice> slices) { this.slices = List.copyOf(slices); revalidate(); repaint(); }
    @Override public Dimension getPreferredSize() {
        return new Dimension(Math.max(760, slices.size() * 92 + 40), 176);
    }
    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int x = 20, y = 44, height = 50;
        long total = slices.stream().mapToLong(GanttSlice::length).sum();
        double scale = total == 0 ? 1 : Math.max(1, getWidth() - 40) / (double) total;
        for (GanttSlice slice : slices) {
            int width = Math.max(2, (int) Math.round(slice.length() * scale));
            Color color = slice.idle() ? ModernTheme.IDLE : Color.getHSBColor(Math.floorMod(slice.pid().hashCode(), 360) / 360f, .57f, .86f);
            g.setColor(color); g.fillRoundRect(x, y, width, height, 10, 10);
            g.setColor(ModernTheme.TEXT); g.setFont(ModernTheme.BOLD);
            if (width > 30) g.drawString(slice.pid(), x + 7, y + 29);
            g.setFont(ModernTheme.SMALL); g.drawString(Long.toString(slice.start()), x, y + height + 20);
            if (x + width < getWidth() - 25) g.drawString(Long.toString(slice.end()), x + width - 18, y + height + 20);
            x += width;
        }
        g.dispose();
    }
}
