package com.ossimulator.ui.components;

import com.ossimulator.theme.ModernTheme;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Draws memory regions and their allocation. */
public final class MemoryMapPanel extends JPanel {
    /** Defines the Span record. */
    public record Span(String label, long start, long size, String detail, Color color) {}
    private List<Span> spans = List.of();
    private long total = 1;
    public MemoryMapPanel() { setBackground(ModernTheme.CARD); }
    public void setSpans(List<Span> spans, long total) {
        this.spans = List.copyOf(spans); this.total = Math.max(1, total); revalidate(); repaint();
    }
    @Override public Dimension getPreferredSize() { return new Dimension(Math.max(760, spans.size() * 150 + 30), 176); }
    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        int x0 = 16, y = 35, width = Math.max(1, getWidth() - 32), height = 62;
        g.setFont(ModernTheme.SMALL);
        for (Span span : spans) {
            int x = x0 + (int) (span.start() / (double) total * width);
            int w = Math.max(2, (int) (span.size() / (double) total * width));
            g.setColor(span.color()); g.fillRoundRect(x, y, w, height, 8, 8);
            g.setColor(ModernTheme.TEXT); g.drawRoundRect(x, y, w, height, 8, 8);
            if (w > 36) { g.drawString(span.label(), x + 6, y + 25); g.drawString(span.detail(), x + 6, y + 46); }
        }
        g.setColor(ModernTheme.TEXT_DIM); g.drawString("Address range: 0 – " + total, x0, y + height + 28);
        g.dispose();
    }
}
