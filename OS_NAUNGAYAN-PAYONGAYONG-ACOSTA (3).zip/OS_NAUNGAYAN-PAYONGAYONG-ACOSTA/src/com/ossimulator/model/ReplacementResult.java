package com.ossimulator.model;

import java.util.List;

/**
 * Page-replacement trace. frameStates.get(i) is the content of every frame after reference i
 * (null entries = empty frame). evicted.get(i) is the page replaced at step i, or null.
 */
/** Stores page-replacement statistics and frame states. */
public record ReplacementResult(String algorithm, int frames, List<Integer> refs,
                                List<List<Integer>> frameStates, List<Boolean> hit,
                                List<Integer> evicted, int hits, int faults,
                                double hitRate, double faultRate) {
}
