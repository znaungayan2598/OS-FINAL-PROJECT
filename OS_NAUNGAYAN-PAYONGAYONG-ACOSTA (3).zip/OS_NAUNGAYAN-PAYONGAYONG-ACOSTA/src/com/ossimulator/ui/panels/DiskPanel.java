package com.ossimulator.ui.panels;

import com.ossimulator.algorithms.DiskScheduler;
import com.ossimulator.model.DiskMove;
import com.ossimulator.model.DiskResult;
import com.ossimulator.ui.components.DiskChartPanel;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/** Provides inputs and results for disk scheduling. */
public final class DiskPanel extends ModulePanelBase {
    private final DefaultTableModel requestModel = model(List.of("Cylinder Request"));
    private final JTable requests = new JTable(requestModel);
    private final JTextField head = textField("53", 7), min = textField("0", 7), max = textField("199", 7);
    private final JComboBox<DiskScheduler.Algorithm> algorithm = new JComboBox<>(new Vector<>(List.of(
            DiskScheduler.Algorithm.FCFS, DiskScheduler.Algorithm.SSTF, DiskScheduler.Algorithm.SCAN,
            DiskScheduler.Algorithm.C_SCAN, DiskScheduler.Algorithm.LOOK, DiskScheduler.Algorithm.C_LOOK)));
    private final JComboBox<DiskScheduler.Direction> direction = new JComboBox<>(new Vector<>(List.of(
            DiskScheduler.Direction.UP, DiskScheduler.Direction.DOWN)));
    private final DiskChartPanel chart = new DiskChartPanel();
    public DiskPanel() {
        super("Disk Scheduling", "Explore request order, head travel, and edge/wrap movement.");
        JPanel options = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)); options.setOpaque(false);
        options.add(labelField("Algorithm", algorithm)); options.add(labelField("Initial head", head));
        options.add(labelField("Min cylinder", min)); options.add(labelField("Max cylinder", max));
        options.add(labelField("Direction", direction));
        addTool("+ Add Request", this::addRequest, false);
        addTool("- Remove Request", this::removeRequest, false);
        addRunButton();
        JPanel card = cardPanel("Cylinder request queue");
        card.add(options, BorderLayout.NORTH); card.add(tableScroll(requests), BorderLayout.CENTER);
        card.add(rowButtons(requests, "Request", this::addRequest), BorderLayout.SOUTH);
        input.add(card, BorderLayout.CENTER); setImportTarget(requests);
    }
    private void addRequest() { Vector<Object> row = new Vector<>(); row.add("98"); requestModel.addRow(row); }
    private void removeRequest() { int r = requests.getSelectedRow(); if (r >= 0) requestModel.removeRow(requests.convertRowIndexToModel(r)); }
    @Override protected JTable importTable() { return requests; }
    @Override protected void loadSample(boolean large) {
        requestModel.setRowCount(0);
        List<Long> values = large ? new ArrayList<>() : List.of(98L, 183L, 37L, 122L, 14L);
        if (large) for (int i = 0; i < 48; i++) values.add((i * 37L + 17) % 200);
        for (long value : values) { Vector<Object> row = new Vector<>(); row.add(value); requestModel.addRow(row); }
        head.setText(large ? "87" : "53"); min.setText("0"); max.setText("199");
    }
    @Override protected void clearData() { requestModel.setRowCount(0); output.setText(""); chart.setResult(null); }
    @Override protected void runSimulation() {
        try {
            long diskMin = InputValidator.parseLong(min.getText(), "Minimum cylinder", 0, Long.MAX_VALUE);
            long diskMax = InputValidator.parseLong(max.getText(), "Maximum cylinder", diskMin, Long.MAX_VALUE);
            long initialHead = InputValidator.parseLong(head.getText(), "Initial head position", diskMin, diskMax);
            List<Long> values = new ArrayList<>();
            for (int i = 0; i < requestModel.getRowCount(); i++)
                values.add(InputValidator.parseLong(cell(requests, i, 0, "Cylinder request"), "Cylinder request", diskMin, diskMax));
            DiskScheduler.Algorithm algo = (DiskScheduler.Algorithm) algorithm.getSelectedItem();
            DiskScheduler.Direction dir = (DiskScheduler.Direction) direction.getSelectedItem();
            runTyped(() -> DiskScheduler.run(values, initialHead, diskMin, diskMax, dir, algo), this::render);
        } catch (Exception e) { showWarning(e); }
    }
    private void render(DiskResult result) {
        chart.setResult(result);
        StringBuilder text = new StringBuilder(result.algorithm()).append("\nService order: ").append(result.serviceOrder())
                .append("\nTotal head movement: ").append(result.totalMovement()).append(" cylinders\n\nStep | From → To | Distance | Type\n");
        int step = 1;
        for (DiskMove move : result.moves()) text.append(step++).append(" | ").append(move.from()).append(" → ")
                .append(move.to()).append(" | ").append(move.distance()).append(" | ").append(move.kind()).append('\n');
        showOutput(text.toString(), chart);
    }
}
