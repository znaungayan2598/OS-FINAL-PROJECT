package com.ossimulator.ui;

import com.ossimulator.theme.ModernTheme;
import com.ossimulator.ui.panels.*;
import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

/** Builds the main window and module navigation. */
public final class MainFrame extends JFrame {
    private final JPanel cards = new JPanel(new CardLayout());
    private final Map<String, JButton> navigation = new LinkedHashMap<>();

    public MainFrame() {
        super("Operating System Simulator");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1120, 760));
        setSize(1440, 900);
        setLocationRelativeTo(null);
        getContentPane().setBackground(ModernTheme.BG);
        setLayout(new BorderLayout());
        add(sidebar(), BorderLayout.WEST);
        add(cards, BorderLayout.CENTER);
        register("CPU Scheduling", new CpuPanel());
        register("Banker's Algorithm", new BankerPanel());
        register("Paging", new PagingPanel());
        register("Page Replacement", new PageReplacementPanel());
        register("Segmentation", new SegmentationPanel());
        register("Fragmentation", new FragmentationPanel());
        register("Disk Scheduling", new DiskPanel());
        register("Multiprogramming", new MultiprogrammingPanel());
        select("CPU Scheduling");
    }
    private JPanel sidebar() {
        JPanel sidebar = new JPanel(new BorderLayout(0, 16));
        sidebar.setBackground(ModernTheme.SIDEBAR);
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 12, 16, 12));
        sidebar.setPreferredSize(new Dimension(230, 0));
        JLabel brand = new JLabel("<html><b>OPERATING SYSTEM</b><br><b>SIMULATOR</b></html>");
        brand.setForeground(ModernTheme.TEXT); brand.setFont(ModernTheme.BOLD);
        JPanel top = new JPanel();
        top.setOpaque(false); top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.add(brand); top.add(Box.createVerticalStrut(24));
        JPanel links = new JPanel(new GridLayout(0, 1, 0, 6));
        links.setOpaque(false);
        java.util.List<String> names = java.util.List.of("CPU Scheduling", "Banker's Algorithm", "Paging", "Page Replacement",
                "Segmentation", "Fragmentation", "Disk Scheduling", "Multiprogramming");
        for (String name : names) {
            int badge = navigation.size() + 1;
            JButton button = new JButton(String.format("%02d   %s", badge, name));
            button.setHorizontalAlignment(SwingConstants.LEFT);
            ModernTheme.styleButton(button, false);
            button.addActionListener(e -> select(name));
            navigation.put(name, button); links.add(button);
        }
        top.add(links);
        sidebar.add(top, BorderLayout.CENTER);
        JLabel footer = new JLabel("Java 17+");
        footer.setFont(ModernTheme.SMALL); footer.setForeground(ModernTheme.TEXT_DIM);
        sidebar.add(footer, BorderLayout.SOUTH);
        return sidebar;
    }
    private void register(String title, JComponent panel) {
        cards.add(panel, title);
    }
    private void select(String title) {
        ((CardLayout) cards.getLayout()).show(cards, title);
        for (Map.Entry<String, JButton> item : navigation.entrySet()) {
            JButton button = item.getValue();
            button.setBackground(item.getKey().equals(title) ? ModernTheme.INDIGO_DARK : ModernTheme.CARD_ALT);
        }
    }
}
