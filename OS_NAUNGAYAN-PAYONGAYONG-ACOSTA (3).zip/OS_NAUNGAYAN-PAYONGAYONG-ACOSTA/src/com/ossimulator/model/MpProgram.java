package com.ossimulator.model;

/** A program in the multiprogramming simulation. */
public record MpProgram(String id, long memory, long burst) {
}
