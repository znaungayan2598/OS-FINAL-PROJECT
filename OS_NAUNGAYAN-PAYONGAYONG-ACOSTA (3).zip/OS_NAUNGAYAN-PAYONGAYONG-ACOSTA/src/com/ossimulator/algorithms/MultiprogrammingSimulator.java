package com.ossimulator.algorithms;

import com.ossimulator.model.MpProgram;
import com.ossimulator.model.MpTick;
import com.ossimulator.model.MultiprogrammingResult;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Deterministic seeded, discrete-time simulation of resident and I/O-waiting programs. */
public final class MultiprogrammingSimulator {
    private MultiprogrammingSimulator() {}

    public static MultiprogrammingResult run(long totalMemory, long osMemory, double ioProbability,
                                             List<MpProgram> programs) {
        if (totalMemory <= 0 || osMemory < 0 || osMemory >= totalMemory)
            throw new IllegalArgumentException("Total RAM must be positive and reserved OS RAM must be smaller than total RAM.");
        if (!Double.isFinite(ioProbability) || ioProbability < 0 || ioProbability > 0.95)
            throw new IllegalArgumentException("I/O probability must be between 0.0 and 0.95.");
        if (programs == null || programs.isEmpty()) throw new IllegalArgumentException("Add at least one program.");
        long usable = totalMemory - osMemory;
        for (MpProgram p : programs) {
            if (p.memory() <= 0 || p.burst() <= 0) throw new IllegalArgumentException("Program memory and burst values must be positive.");
            if (p.memory() > usable) throw new IllegalArgumentException(p.id() + " cannot fit in usable RAM.");
        }
        List<Long> remaining = new ArrayList<>();
        List<Integer> io = new ArrayList<>();
        List<Boolean> loaded = new ArrayList<>();
        List<Boolean> completed = new ArrayList<>();
        for (MpProgram p : programs) { remaining.add(p.burst()); io.add(0); loaded.add(false); completed.add(false); }
        List<MpTick> ticks = new ArrayList<>();
        Random random = new Random(17);
        long used = 0, tick = 0, peakUsed = 0;
        int cursor = 0, finished = 0, peakDegree = 0;
        while (finished < programs.size()) {
            List<String> inMemory = new ArrayList<>(), inIo = new ArrayList<>(), waiting = new ArrayList<>();
            for (int i = 0; i < programs.size(); i++) {
                if (!completed.get(i) && !loaded.get(i) && programs.get(i).memory() <= usable - used) {
                    loaded.set(i, true);
                    used += programs.get(i).memory();
                }
                if (loaded.get(i)) inMemory.add(programs.get(i).id());
                else if (!completed.get(i)) waiting.add(programs.get(i).id());
                if (loaded.get(i) && io.get(i) > 0) inIo.add(programs.get(i).id());
            }
            peakUsed = Math.max(peakUsed, used);
            peakDegree = Math.max(peakDegree, inMemory.size());
            int chosen = -1;
            for (int count = 0; count < programs.size(); count++) {
                int candidate = (cursor + count) % programs.size();
                if (loaded.get(candidate) && remaining.get(candidate) > 0 && io.get(candidate) == 0) {
                    chosen = candidate;
                    break;
                }
            }
            if (chosen < 0 && inMemory.isEmpty()) throw new IllegalStateException("No program can be loaded; check memory requirements.");
            String cpu = chosen < 0 ? "IDLE" : programs.get(chosen).id();
            if (chosen >= 0) {
                remaining.set(chosen, remaining.get(chosen) - 1);
                cursor = (chosen + 1) % programs.size();
                if (remaining.get(chosen) == 0) {
                    used -= programs.get(chosen).memory();
                    loaded.set(chosen, false);
                    completed.set(chosen, true);
                    finished++;
                } else if (random.nextDouble() < ioProbability) io.set(chosen, 2);
            }
            ticks.add(new MpTick(++tick, cpu, List.copyOf(inIo), List.copyOf(inMemory),
                    List.copyOf(waiting), chosen >= 0, chosen >= 0 ? "CPU burst tick" : "All resident programs waiting for I/O"));
            for (int i = 0; i < io.size(); i++) if (io.get(i) > 0) io.set(i, io.get(i) - 1);
        }
        double memoryUtilization = 100.0 * peakUsed / usable;
        double cpuUtilization = 100.0 * (1.0 - Math.pow(ioProbability, peakDegree));
        return new MultiprogrammingResult(peakDegree, usable, memoryUtilization, cpuUtilization, List.copyOf(ticks));
    }
}
