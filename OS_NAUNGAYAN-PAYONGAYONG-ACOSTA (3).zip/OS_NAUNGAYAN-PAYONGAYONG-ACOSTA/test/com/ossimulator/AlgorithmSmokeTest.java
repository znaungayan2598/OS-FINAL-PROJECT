package com.ossimulator;

import com.ossimulator.algorithms.*;
import com.ossimulator.model.*;
import com.ossimulator.utils.BulkInput;
import java.util.List;

/** Dependency-free regression checks; run with assertions enabled or use the checks below. */
public final class AlgorithmSmokeTest {
    private AlgorithmSmokeTest() {}
    public static void main(String... args) {
        cpuScheduling();
        preemptiveAndRoundRobin();
        bankersSafety();
        pagingTranslation();
        pageReplacement();
        segmentationBounds();
        fragmentationAllocation();
        diskScheduling();
        multiprogramming();
        bulkInputBom();
        largeInputs();
        System.out.println("Algorithm smoke tests passed.");
    }
    private static void cpuScheduling() {
        CpuResult result = CpuScheduler.run(List.of(new ProcessInfo("A", 0, 3, 1),
                new ProcessInfo("B", 1, 2, 1)), CpuScheduler.Algorithm.FCFS, 1);
        check(result.processes().get(1).completion() == 5, "FCFS completion");
        check(result.processes().get(1).waiting() == 2, "FCFS waiting");
        check(result.gantt().size() == 2, "FCFS Gantt slices");
    }
    private static void preemptiveAndRoundRobin() {
        List<ProcessInfo> processes = List.of(new ProcessInfo("A", 0, 8, 2),
                new ProcessInfo("B", 1, 4, 1));
        CpuResult shortest = CpuScheduler.run(processes, CpuScheduler.Algorithm.SRTF, 2);
        check(shortest.processes().get(1).completion() == 5, "SRTF preemption");
        CpuResult priority = CpuScheduler.run(processes, CpuScheduler.Algorithm.PRIORITY_P, 2);
        check(priority.processes().get(1).completion() == 5, "Preemptive priority");
        CpuResult roundRobin = CpuScheduler.run(List.of(new ProcessInfo("A", 0, 3, 1),
                new ProcessInfo("B", 0, 2, 1)), CpuScheduler.Algorithm.ROUND_ROBIN, 2);
        check(roundRobin.processes().get(1).completion() == 4, "Round Robin quantum");
    }
    private static void bankersSafety() {
        List<List<Long>> alloc = List.of(List.of(0L, 1L, 0L), List.of(2L, 0L, 0L),
                List.of(3L, 0L, 2L), List.of(2L, 1L, 1L), List.of(0L, 0L, 2L));
        List<List<Long>> max = List.of(List.of(7L, 5L, 3L), List.of(3L, 2L, 2L),
                List.of(9L, 0L, 2L), List.of(2L, 2L, 2L), List.of(4L, 3L, 3L));
        BankerResult result = BankersAlgorithm.run(List.of("P0", "P1", "P2", "P3", "P4"),
                alloc, max, List.of(3L, 3L, 2L));
        check(result.safe(), "Banker's safe state");
        check(result.safeSequence().size() == 5, "Banker's sequence length");
    }
    private static void pagingTranslation() {
        List<PagingRow> rows = PagingAlgorithm.translate(100, 2, List.of(2L, -1L), List.of(50L, 150L));
        check(rows.get(0).physical() == 250L, "Paging physical address");
        check(!rows.get(1).ok(), "Paging fault");
    }
    private static void pageReplacement() {
        ReplacementResult result = PageReplacement.run(List.of(1, 2, 3, 1), 3, PageReplacement.Algorithm.FIFO);
        check(result.hits() == 1 && result.faults() == 3, "FIFO hit/fault totals");
        check(result.frameStates().get(0).get(0) == 1, "FIFO frame trace with empty slots");
    }
    private static void segmentationBounds() {
        List<SegmentResult> results = SegmentationAlgorithm.translate(List.of(new SegmentEntry(0, 100, 10)),
                List.of(new SegmentQuery(0, 9), new SegmentQuery(0, 10)));
        check(results.get(0).physical() == 109L && results.get(0).ok(), "Valid segment address");
        check(!results.get(1).ok(), "Out-of-range segment address");
    }
    private static void fragmentationAllocation() {
        FragResult result = FragmentationAlgorithm.run(List.of(100L, 200L),
                List.of(new FragProcess("A", 90), new FragProcess("B", 50)),
                FragmentationAlgorithm.Strategy.FIRST_FIT);
        check(result.internalFrag() == 160 && result.externalFrag() == 0, "Partition fragmentation totals");
    }
    private static void diskScheduling() {
        DiskResult result = DiskScheduler.run(List.of(40L, 10L), 20, 0, 100,
                DiskScheduler.Direction.UP, DiskScheduler.Algorithm.FCFS);
        check(result.totalMovement() == 50, "FCFS disk movement");
        DiskResult circular = DiskScheduler.run(List.of(10L, 20L, 50L, 80L), 45, 0, 100,
                DiskScheduler.Direction.UP, DiskScheduler.Algorithm.C_LOOK);
        check(circular.serviceOrder().equals(List.of(50L, 80L, 10L, 20L)), "C-LOOK service order");
        check(runDisk(DiskScheduler.Algorithm.SSTF).serviceOrder().equals(List.of(40L, 10L, 90L)), "SSTF service order");
        check(runDisk(DiskScheduler.Algorithm.LOOK).serviceOrder().equals(List.of(90L, 40L, 10L)), "LOOK service order");
        check(runDisk(DiskScheduler.Algorithm.SCAN).serviceOrder().equals(List.of(90L, 40L, 10L)), "SCAN service order");
        check(runDisk(DiskScheduler.Algorithm.C_SCAN).serviceOrder().equals(List.of(90L, 10L, 40L)), "C-SCAN service order");
    }
    private static DiskResult runDisk(DiskScheduler.Algorithm algorithm) {
        return DiskScheduler.run(List.of(10L, 40L, 90L), 50, 0, 100,
                DiskScheduler.Direction.UP, algorithm);
    }
    private static void multiprogramming() {
        MultiprogrammingResult result = MultiprogrammingSimulator.run(2048, 256, 0,
                List.of(new MpProgram("A", 1000, 1), new MpProgram("B", 1000, 1),
                        new MpProgram("C", 1000, 1)));
        check(result.degree() == 1 || result.degree() == 2, "Multiprogramming resident degree");
        check(result.cpuUtilization() == 100.0, "Multiprogramming CPU utilization");
        check(!result.ticks().isEmpty(), "Multiprogramming tick trace");
    }
    private static void bulkInputBom() {
        check(BulkInput.tokens("\uFEFF1, 2").equals(List.of("1", "2")), "UTF-8 BOM parsing");
    }
    private static void largeInputs() {
        List<ProcessInfo> processes = new java.util.ArrayList<>();
        List<Integer> references = new java.util.ArrayList<>();
        List<Long> requests = new java.util.ArrayList<>();
        List<Long> blocks = new java.util.ArrayList<>();
        List<FragProcess> allocations = new java.util.ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            processes.add(new ProcessInfo("P" + i, 0, 1 + i % 4, i % 5));
            references.add(i % 41);
            requests.add((long) (i % 200));
            blocks.add(64L);
            allocations.add(new FragProcess("M" + i, 32));
        }
        check(CpuScheduler.run(processes, CpuScheduler.Algorithm.SRTF, 2).processes().size() == 1000,
                "CPU scheduler scales to 1,000 processes");
        check(PageReplacement.run(references, 32, PageReplacement.Algorithm.LRU).refs().size() == 1000,
                "Page replacement scales to 1,000 references");
        check(DiskScheduler.run(requests, 100, 0, 199, DiskScheduler.Direction.UP,
                DiskScheduler.Algorithm.FCFS).serviceOrder().size() == 1000,
                "Disk scheduler scales to 1,000 requests");
        check(FragmentationAlgorithm.run(blocks, allocations, FragmentationAlgorithm.Strategy.FIRST_FIT)
                .allocatedCount() == 1000, "Fragmentation scales to 1,000 rows");
    }
    private static void check(boolean passed, String label) {
        if (!passed) throw new AssertionError(label);
    }
}
