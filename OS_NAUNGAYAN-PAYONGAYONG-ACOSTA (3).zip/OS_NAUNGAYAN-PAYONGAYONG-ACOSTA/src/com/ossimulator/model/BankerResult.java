package com.ossimulator.model;

import java.util.List;

/** Result of the Banker's safety algorithm. */
public record BankerResult(List<String> processIds, List<List<Long>> need, List<BankerStep> steps, boolean safe,
                           List<String> safeSequence, List<String> unfinished) {
}
