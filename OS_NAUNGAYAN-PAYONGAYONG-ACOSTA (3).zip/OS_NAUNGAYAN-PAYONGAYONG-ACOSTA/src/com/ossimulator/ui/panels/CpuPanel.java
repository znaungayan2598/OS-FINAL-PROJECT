package com.ossimulator.ui.panels;

import com.ossimulator.algorithms.CpuScheduler;
import com.ossimulator.model.CpuResult;
import com.ossimulator.model.ProcessInfo;
import com.ossimulator.model.ProcessStats;
import com.ossimulator.ui.components.GanttChartPanel;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Vector;
import java.util.HashSet;
import java.util.Set;

/** Provides inputs and results for CPU scheduling. */
public final class CpuPanel extends ModulePanelBase {
    private final DefaultTableModel tableModel = model(List.of("Process ID", "Arrival Time", "Burst Time", "Priority"));
    private final JTable table = new JTable(tableModel);
    private final JComboBox<CpuScheduler.Algorithm> algorithm = new JComboBox<>(new Vector<>(List.of(
            CpuScheduler.Algorithm.FCFS, CpuScheduler.Algorithm.SJF, CpuScheduler.Algorithm.SRTF,
            CpuScheduler.Algorithm.PRIORITY_NP, CpuScheduler.Algorithm.PRIORITY_P, CpuScheduler.Algorithm.ROUND_ROBIN)));
    private final JTextField quantum = textField("2", 7);
    private final GanttChartPanel chart = new GanttChartPanel();

    public CpuPanel() {
        super("CPU Scheduling", "Compare classic schedulers with a scalable process table and exact timing metrics.");
        JPanel options = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)); options.setOpaque(false);
        options.add(labelField("Algorithm", algorithm)); options.add(labelField("Time quantum", quantum));
        addTool("+ Add Process", this::addProcess, false);
        addTool("Generate N Random Processes", this::generateRandom, false);
        addTool("- Remove Process", this::removeProcess, false);
        addRunButton();
        JPanel card = cardPanel("Ready queue");
        card.add(options, BorderLayout.NORTH);
        card.add(tableScroll(table), BorderLayout.CENTER);
        card.add(rowButtons(table, "Process", this::addProcess), BorderLayout.SOUTH);
        input.add(card, BorderLayout.CENTER);
        setImportTarget(table);
    }
    private void addProcess() {
        Vector<Object> row = new Vector<>(); row.add("P" + tableModel.getRowCount()); row.add("0"); row.add("5"); row.add("1");
        tableModel.addRow(row);
    }
    private void removeProcess() {
        int selected = table.getSelectedRow();
        if (selected >= 0) tableModel.removeRow(table.convertRowIndexToModel(selected));
    }
    private void generateRandom() {
        String text = JOptionPane.showInputDialog(this, "How many processes should be generated?", "Generate Processes", JOptionPane.QUESTION_MESSAGE);
        if (text == null) return;
        try {
            int count = InputValidator.parseInt(text, "Process count", 1, Integer.MAX_VALUE);
            Random random = new Random();
            for (int i = 0; i < count; i++) {
                Vector<Object> row = new Vector<>(); row.add("P" + (tableModel.getRowCount())); row.add(random.nextInt(30));
                row.add(1 + random.nextInt(20)); row.add(1 + random.nextInt(10)); tableModel.addRow(row);
            }
        } catch (InputValidator.InvalidInputException e) { showWarning(e); }
    }
    @Override protected void loadSample(boolean large) {
        tableModel.setRowCount(0);
        int count = large ? 35 : 5;
        for (int i = 0; i < count; i++) {
            Vector<Object> row = new Vector<>(); row.add("P" + i);
            row.add(large ? (i * 3) % 17 : List.of(0, 1, 2, 3, 4).get(i));
            row.add(large ? 2 + (i * 7) % 19 : List.of(7, 4, 1, 4, 2).get(i));
            row.add(large ? 1 + (i * 5) % 9 : List.of(2, 1, 3, 2, 1).get(i));
            tableModel.addRow(row);
        }
        output.setText(large ? "Loaded 35 editable processes." : "Loaded five editable sample processes.");
    }
    @Override protected void clearData() { tableModel.setRowCount(0); output.setText(""); chart.setSlices(List.of()); }
    @Override protected JTable importTable() { return table; }
    @Override protected void runSimulation() {
        try {
            List<ProcessInfo> processes = new ArrayList<>();
            Set<String> ids = new HashSet<>();
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String id = cell(table, i, 0, "Process ID");
                if (!ids.add(id)) throw new InputValidator.InvalidInputException("Process IDs must be unique: " + id + ".");
                long arrival = InputValidator.parseLong(cell(table, i, 1, "Arrival time"), "Arrival time", 0, Long.MAX_VALUE);
                long burst = InputValidator.parseLong(cell(table, i, 2, "Burst time"), "Burst time", 1, Long.MAX_VALUE);
                int priority = InputValidator.parseInt(cell(table, i, 3, "Priority"), "Priority", Integer.MIN_VALUE, Integer.MAX_VALUE);
                processes.add(new ProcessInfo(id, arrival, burst, priority));
            }
            CpuScheduler.Algorithm selected = (CpuScheduler.Algorithm) algorithm.getSelectedItem();
            long q = InputValidator.parseLong(quantum.getText(), "Time quantum", 1, Long.MAX_VALUE);
            runTyped(() -> CpuScheduler.run(processes, selected, q), this::render);
        } catch (Exception e) { showWarning(e); }
    }
    private void render(CpuResult result) {
        chart.setSlices(result.gantt());
        StringBuilder text = new StringBuilder(result.algorithm()).append("\n\nProcess | Arrival | Burst | Completion | Turnaround | Waiting | Response\n");
        for (ProcessStats p : result.processes()) text.append(p.id()).append(" | ").append(p.arrival()).append(" | ")
                .append(p.burst()).append(" | ").append(p.completion()).append(" | ").append(p.turnaround())
                .append(" | ").append(p.waiting()).append(" | ").append(p.response()).append('\n');
        text.append(String.format("\nAverage waiting: %.2f\nAverage turnaround: %.2f\nCPU utilization: %.2f%%",
                result.averageWaiting(), result.averageTurnaround(), result.utilization()));
        showOutput(text.toString(), chart);
    }
}
