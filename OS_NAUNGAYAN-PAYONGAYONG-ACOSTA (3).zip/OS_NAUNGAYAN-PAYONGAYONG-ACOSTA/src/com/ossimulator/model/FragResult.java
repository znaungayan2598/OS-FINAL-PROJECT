package com.ossimulator.model;

import java.util.List;

/**
 * Result of a partition-allocation run. allocation.get(i) is the index (in blocks) of the
 * block given to process i, or -1 if it could not be placed. blockUsed.get(b) is the amount of
 * block b that is occupied (0 when the block stayed free).
 */
/** Stores the result of memory partition allocation. */
public record FragResult(String strategy, List<MemoryBlock> blocks, List<FragProcess> processes,
                         List<Integer> allocation, List<Long> blockUsed, long internalFrag,
                         long externalFrag, long totalFree, int allocatedCount, int unallocatedCount) {
}
