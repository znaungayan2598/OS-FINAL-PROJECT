package com.ossimulator.ui.panels;

import com.ossimulator.algorithms.MultiprogrammingSimulator;
import com.ossimulator.model.MpProgram;
import com.ossimulator.model.MpTick;
import com.ossimulator.model.MultiprogrammingResult;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.HashSet;
import java.util.Set;

/** Provides inputs and results for multiprogramming. */
public final class MultiprogrammingPanel extends ModulePanelBase {
    private final JTextField ram = textField("2048", 8), reserved = textField("256", 8), probability = textField("0.3", 8);
    private final DefaultTableModel programModel = model(List.of("Program ID", "Memory Required (MB)", "CPU Burst (ticks)"));
    private final JTable programs = new JTable(programModel);
    public MultiprogrammingPanel() {
        super("Multiprogramming", "Model resident programs, memory contention, I/O waits and CPU utilization.");
        JPanel config = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)); config.setOpaque(false);
        config.add(labelField("Total RAM (MB)", ram)); config.add(labelField("OS reserved (MB)", reserved));
        config.add(labelField("I/O wait probability (0–0.95)", probability));
        JPanel card = cardPanel("Program workload");
        card.add(config, BorderLayout.NORTH); card.add(tableScroll(programs), BorderLayout.CENTER);
        card.add(rowButtons(programs, "Program", this::addProgram), BorderLayout.SOUTH);
        input.add(card, BorderLayout.CENTER);
        addTool("+ Add Program", this::addProgram, false); addTool("- Remove Program", this::removeProgram, false);
        addRunButton(); setImportTarget(programs);
    }
    private void addProgram() {
        Vector<Object> row = new Vector<>(); row.add("Program" + programModel.getRowCount()); row.add(""); row.add("");
        programModel.addRow(row);
    }
    private void removeProgram() { int r = programs.getSelectedRow(); if (r >= 0) programModel.removeRow(programs.convertRowIndexToModel(r)); }
    @Override protected void loadSample(boolean large) {
        programModel.setRowCount(0); ram.setText(large ? "8192" : "2048"); reserved.setText(large ? "512" : "256");
        probability.setText("0.3");
        int count = large ? 42 : 5;
        for (int i = 0; i < count; i++) {
            Vector<Object> row = new Vector<>(); row.add("P" + i);
            row.add(large ? 200 + (i * 83) % 1200 : List.of(512, 640, 384, 768, 480).get(i));
            row.add(large ? 8 + (i * 7) % 25 : List.of(12, 8, 15, 6, 10).get(i));
            programModel.addRow(row);
        }
    }
    @Override protected void clearData() { programModel.setRowCount(0); output.setText(""); }
    @Override protected JTable importTable() { return programs; }
    @Override protected void runSimulation() {
        try {
            long totalRam = InputValidator.parseLong(ram.getText(), "Total RAM", 1, Long.MAX_VALUE);
            long osRam = InputValidator.parseLong(reserved.getText(), "OS reserved RAM", 0, Long.MAX_VALUE);
            double ioWait = InputValidator.parseDouble(probability.getText(), "I/O wait probability", 0, .95);
            List<MpProgram> data = new ArrayList<>();
            Set<String> ids = new HashSet<>();
            for (int i = 0; i < programModel.getRowCount(); i++) {
                String id = cell(programs, i, 0, "Program ID");
                if (!ids.add(id)) throw new InputValidator.InvalidInputException("Program IDs must be unique: " + id + ".");
                data.add(new MpProgram(id,
                        InputValidator.parseLong(cell(programs, i, 1, "Memory required"), "Memory required", 1, Long.MAX_VALUE),
                        InputValidator.parseLong(cell(programs, i, 2, "CPU burst"), "CPU burst", 1, Long.MAX_VALUE)));
            }
            runTyped(() -> MultiprogrammingSimulator.run(totalRam, osRam, ioWait, data), this::render);
        } catch (Exception e) { showWarning(e); }
    }
    private void render(MultiprogrammingResult result) {
        StringBuilder text = new StringBuilder("Degree of multiprogramming: ").append(result.degree())
                .append("\nUsable RAM: ").append(result.usableMemory()).append(" MB")
                .append(String.format("\nPeak memory utilization: %.2f%%\nCPU utilization (1 - p^n): %.2f%%",
                        result.memoryUtilization(), result.cpuUtilization()))
                .append("\n\nTick | CPU | In I/O | Resident | Waiting | Event\n");
        for (MpTick tick : result.ticks()) text.append(tick.tick()).append(" | ").append(tick.cpuProgram())
                .append(" | ").append(tick.inIo()).append(" | ").append(tick.inMemory()).append(" | ")
                .append(tick.waiting()).append(" | ").append(tick.event()).append('\n');
        showOutput(text.toString());
    }
}
