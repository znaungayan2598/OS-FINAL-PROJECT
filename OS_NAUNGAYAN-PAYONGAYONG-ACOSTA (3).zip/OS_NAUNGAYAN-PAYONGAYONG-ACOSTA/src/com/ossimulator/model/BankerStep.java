package com.ossimulator.model;

/** One row of the safety-check trace. */
public record BankerStep(int step, String process, String need, String workBefore,
                         String workAfter, String finish, String note) {
}
