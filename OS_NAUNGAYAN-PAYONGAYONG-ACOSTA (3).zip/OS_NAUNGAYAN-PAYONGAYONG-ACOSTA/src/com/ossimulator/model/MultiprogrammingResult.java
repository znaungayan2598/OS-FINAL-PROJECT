package com.ossimulator.model;

import java.util.List;

/** Stores multiprogramming metrics and execution trace. */
public record MultiprogrammingResult(int degree, long usableMemory, double memoryUtilization,
                                     double cpuUtilization, List<MpTick> ticks) {
}
