package com.ossimulator;

import com.ossimulator.theme.ModernTheme;
import com.ossimulator.ui.MainFrame;
import javax.swing.SwingUtilities;

/** Application entry point. */
public final class Main {
    private Main() {}
    public static void main(String... args) {
        SwingUtilities.invokeLater(() -> {
            ModernTheme.install();
            new MainFrame().setVisible(true);
        });
    }
}
