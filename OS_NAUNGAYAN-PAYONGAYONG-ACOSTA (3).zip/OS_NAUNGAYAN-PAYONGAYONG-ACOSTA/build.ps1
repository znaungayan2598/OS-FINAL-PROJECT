$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

if (Test-Path "out") {
    Remove-Item -LiteralPath "out" -Recurse -Force
}
New-Item -ItemType Directory -Force "out" | Out-Null

$sources = Get-ChildItem -Path "src" -Recurse -Filter "*.java" |
    ForEach-Object { $_.FullName }

javac -encoding UTF-8 -d "out" $sources
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

jar cfe "OperatingSystemSimulator.jar" "com.ossimulator.Main" -C "out" .
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

Write-Host "Built OperatingSystemSimulator.jar"
