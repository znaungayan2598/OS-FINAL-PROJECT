package com.ossimulator.ui.panels;

import com.ossimulator.theme.ModernTheme;
import com.ossimulator.utils.AsyncRunner;
import com.ossimulator.utils.BulkInput;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.util.List;
import java.util.Vector;
import java.util.function.Supplier;

/** Shared layout, data import, styling and asynchronous simulation support. */
public abstract class ModulePanelBase extends JPanel {
    protected final JPanel tools = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 7));
    protected final JPanel input = new JPanel(new BorderLayout(8, 8));
    protected final JPanel resultHost = new JPanel(new BorderLayout(8, 8));
    protected final JTextArea output = new JTextArea();
    protected JTable importTarget;
    protected JButton runButton;

    protected ModulePanelBase(String title, String subtitle) {
        setLayout(new BorderLayout(0, 10));
        setBackground(ModernTheme.BG);
        JPanel top = new JPanel(new BorderLayout(0, 8));
        top.setOpaque(false);
        JLabel heading = new JLabel(title);
        heading.setFont(ModernTheme.TITLE); heading.setForeground(ModernTheme.TEXT);
        JLabel description = new JLabel(subtitle);
        description.setFont(ModernTheme.SMALL); description.setForeground(ModernTheme.TEXT_DIM);
        JPanel labels = new JPanel(new GridLayout(0, 1, 0, 3));
        labels.setOpaque(false); labels.add(heading); labels.add(description);
        top.add(labels, BorderLayout.NORTH);
        tools.setOpaque(false);
        addTool("Load Small Sample", () -> loadSample(false), false);
        addTool("Load Large Dataset", () -> loadSample(true), false);
        addTool("Import CSV/TXT", this::importData, false);
        addTool("Clear All", this::clearData, false);
        top.add(tools, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        input.setOpaque(false);
        input.setBorder(ModernTheme.cardBorder());
        output.setEditable(false); output.setLineWrap(false); output.setFont(ModernTheme.MONO);
        output.setBackground(ModernTheme.FIELD); output.setForeground(ModernTheme.TEXT);
        output.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JScrollPane outputScroll = new JScrollPane(output);
        ModernTheme.styleScrollPane(outputScroll);
        resultHost.setBorder(ModernTheme.cardBorder());
        resultHost.setBackground(ModernTheme.CARD);
        resultHost.add(outputScroll, BorderLayout.CENTER);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, input, resultHost);
        split.setResizeWeight(.54); split.setBorder(null); split.setContinuousLayout(true);
        split.setBackground(ModernTheme.BG);
        add(split, BorderLayout.CENTER);
    }

    protected abstract void loadSample(boolean large);
    protected abstract void clearData();
    protected abstract void runSimulation();
    protected abstract JTable importTable();

    protected final JButton addTool(String label, Runnable action, boolean primary) {
        JButton button = new JButton(label);
        ModernTheme.styleButton(button, primary);
        button.addActionListener(e -> {
            try { action.run(); }
            catch (RuntimeException ex) { InputValidator.showFailure(this, ex); }
        });
        tools.add(button);
        if (primary) runButton = button;
        return button;
    }
    protected final void setImportTarget(JTable table) { importTarget = table; }
    protected final void addRunButton() {
        addTool("Run Simulation", this::runSimulation, true);
    }
    protected final <T> void runTyped(Supplier<T> task, java.util.function.Consumer<T> done) {
        AsyncRunner.run(this, task::get, done, runButton);
    }
    protected final void showOutput(String text) {
        resultHost.removeAll();
        JScrollPane pane = new JScrollPane(output);
        ModernTheme.styleScrollPane(pane);
        resultHost.add(pane, BorderLayout.CENTER);
        output.setText(text); output.setCaretPosition(0);
        resultHost.revalidate(); resultHost.repaint();
    }
    protected final void showOutput(String text, JComponent chart) {
        resultHost.removeAll();
        JScrollPane chartScroll = new JScrollPane(chart,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        ModernTheme.styleScrollPane(chartScroll);
        output.setText(text); output.setCaretPosition(0);
        JScrollPane textScroll = new JScrollPane(output);
        ModernTheme.styleScrollPane(textScroll);
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, chartScroll, textScroll);
        split.setResizeWeight(.58); split.setBorder(null);
        resultHost.add(split, BorderLayout.CENTER);
        resultHost.revalidate(); resultHost.repaint();
    }
    protected final JPanel cardPanel(String title) {
        JPanel panel = new ModernTheme.RoundedPanel(new BorderLayout(6, 6));
        panel.setBackground(ModernTheme.CARD);
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(7, 10, 7, 10), title,
                0, 0, ModernTheme.BOLD, ModernTheme.TEXT));
        return panel;
    }
    protected final JScrollPane tableScroll(JTable table) {
        ModernTheme.styleTable(table);
        JScrollPane scroll = new JScrollPane(table,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        ModernTheme.styleScrollPane(scroll);
        return scroll;
    }
    protected final JPanel rowButtons(JTable table, String addLabel, Runnable addAction) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 7, 0));
        panel.setOpaque(false);
        JButton add = new JButton("+ " + addLabel);
        ModernTheme.styleButton(add, false); add.addActionListener(e -> addAction.run());
        JButton remove = new JButton("- Remove Selected");
        ModernTheme.styleButton(remove, false);
        remove.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) ((DefaultTableModel) table.getModel()).removeRow(table.convertRowIndexToModel(row));
        });
        panel.add(add); panel.add(remove); return panel;
    }
    protected void importData() {
        if (importTarget == null) { InputValidator.warn(this, "There is no table available for CSV import."); return; }
        importIntoTable(importTarget);
    }
    protected final void importIntoTable(JTable target) {
        java.io.File file = BulkInput.chooseFile(this);
        if (file == null) return;
        try {
            List<List<String>> rows = BulkInput.lines(BulkInput.readFile(file), false);
            DefaultTableModel model = (DefaultTableModel) target.getModel();
            int columns = model.getColumnCount();
            if (!rows.isEmpty() && looksLikeHeader(rows.get(0), model)) rows.remove(0);
            for (List<String> row : rows) {
                if (row.size() != columns) throw new IllegalArgumentException("CSV row has " + row.size()
                        + " columns; expected " + columns + ".");
            }
            for (List<String> row : rows) model.addRow(new Vector<>(row));
            output.setText("Imported " + rows.size() + " rows from " + file.getName() + ".");
        } catch (IOException e) {
            InputValidator.showFailure(this, e);
        }
    }
    protected final JTable chooseImportTable(List<String> labels, List<JTable> tables) {
        if (labels.size() != tables.size() || labels.isEmpty())
            throw new IllegalArgumentException("CSV import destinations are not configured.");
        JComboBox<String> choices = new JComboBox<>(new Vector<>(labels));
        int answer = JOptionPane.showConfirmDialog(this, choices, "Import into which table?",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        return answer == JOptionPane.OK_OPTION ? tables.get(choices.getSelectedIndex()) : null;
    }
    private boolean looksLikeHeader(List<String> first, DefaultTableModel model) {
        if (first.size() != model.getColumnCount()) return false;
        for (int i = 0; i < first.size(); i++)
            if (!first.get(i).trim().equalsIgnoreCase(model.getColumnName(i).trim())) return false;
        return true;
    }
    protected static DefaultTableModel model(List<String> columns) {
        return new DefaultTableModel(new Vector<>(), new Vector<>(columns)) {
            @Override public boolean isCellEditable(int row, int column) { return true; }
        };
    }
    protected final String cell(JTable table, int row, int column, String name) throws InputValidator.InvalidInputException {
        Object value = table.getValueAt(row, column);
        if (value == null || value.toString().trim().isEmpty()) throw new InputValidator.InvalidInputException(name + " at row " + (row + 1) + " is required.");
        return value.toString().trim();
    }
    protected final JPanel labelField(String label, JComponent field) {
        JPanel wrapper = new JPanel(new BorderLayout(5, 4));
        wrapper.setOpaque(false);
        JLabel caption = new JLabel(label); caption.setForeground(ModernTheme.TEXT_DIM); caption.setFont(ModernTheme.SMALL);
        wrapper.add(caption, BorderLayout.NORTH); wrapper.add(field, BorderLayout.CENTER);
        return wrapper;
    }
    protected final JTextField textField(String initial, int columns) {
        JTextField field = new JTextField(initial, columns);
        field.setBackground(ModernTheme.FIELD); field.setForeground(ModernTheme.TEXT);
        field.setCaretColor(ModernTheme.TEXT); field.setFont(ModernTheme.BASE);
        return field;
    }
    protected final void showWarning(Throwable error) { InputValidator.showFailure(this, error); }
}
