package com.ossimulator.model;

/** One row of the segment table. */
public record SegmentEntry(long number, long base, long limit) {
}
