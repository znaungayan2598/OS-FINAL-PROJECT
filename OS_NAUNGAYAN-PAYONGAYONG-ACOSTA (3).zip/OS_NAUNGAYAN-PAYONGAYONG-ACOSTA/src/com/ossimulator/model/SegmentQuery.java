package com.ossimulator.model;

/** A logical address expressed as (segment number, offset). */
public record SegmentQuery(long segment, long offset) {
}
