package com.ossimulator.model;

import java.util.List;

/** Snapshot of one simulated clock tick of the multiprogramming simulator. */
public record MpTick(long tick, String cpuProgram, List<String> inIo, List<String> inMemory,
                     List<String> waiting, boolean cpuBusy, String event) {
}
