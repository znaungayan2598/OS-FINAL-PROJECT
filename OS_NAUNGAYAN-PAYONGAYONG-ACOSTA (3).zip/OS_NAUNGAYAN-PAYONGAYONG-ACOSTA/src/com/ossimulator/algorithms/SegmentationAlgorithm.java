package com.ossimulator.algorithms;

import com.ossimulator.model.SegmentEntry;
import com.ossimulator.model.SegmentQuery;
import com.ossimulator.model.SegmentResult;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Translates logical addresses through a segment table. */
public final class SegmentationAlgorithm {
    private SegmentationAlgorithm() {}
    public static List<SegmentResult> translate(List<SegmentEntry> segments, List<SegmentQuery> queries) {
        Map<Long, SegmentEntry> table = new HashMap<>();
        for (SegmentEntry segment : segments) {
            if (segment.base() < 0 || segment.limit() <= 0) throw new IllegalArgumentException("Segment bases must be non-negative and limits positive.");
            if (table.put(segment.number(), segment) != null) throw new IllegalArgumentException("Segment numbers must be unique.");
            Math.addExact(segment.base(), segment.limit());
        }
        List<SegmentResult> results = new ArrayList<>();
        for (SegmentQuery query : queries) {
            SegmentEntry entry = table.get(query.segment());
            if (entry == null) results.add(new SegmentResult(query.segment(), query.offset(), null, null, null, false, "Segmentation fault: segment does not exist."));
            else if (query.offset() < 0 || query.offset() >= entry.limit())
                results.add(new SegmentResult(query.segment(), query.offset(), entry.base(), entry.limit(), null, false, "Segmentation fault: offset is outside segment limit."));
            else results.add(new SegmentResult(query.segment(), query.offset(), entry.base(), entry.limit(),
                        Math.addExact(entry.base(), query.offset()), true, "Valid address"));
        }
        return List.copyOf(results);
    }
}
