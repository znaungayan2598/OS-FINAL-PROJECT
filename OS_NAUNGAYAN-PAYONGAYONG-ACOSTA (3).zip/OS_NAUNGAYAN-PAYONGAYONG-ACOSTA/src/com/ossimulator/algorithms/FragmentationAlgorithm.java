package com.ossimulator.algorithms;

import com.ossimulator.model.FragProcess;
import com.ossimulator.model.FragResult;
import com.ossimulator.model.MemoryBlock;
import java.util.ArrayList;
import java.util.List;

/** Implements fixed-partition memory allocation. */
public final class FragmentationAlgorithm {
    private FragmentationAlgorithm() {}
    /** Lists memory partition allocation strategies. */
    public enum Strategy { FIRST_FIT, BEST_FIT, WORST_FIT }

    public static FragResult run(List<Long> inputBlocks, List<FragProcess> processes, Strategy strategy) {
        if (inputBlocks == null || processes == null || inputBlocks.isEmpty())
            throw new IllegalArgumentException("Add at least one memory block and one process.");
        List<MemoryBlock> blocks = new ArrayList<>();
        List<Long> remaining = new ArrayList<>();
        for (int i = 0; i < inputBlocks.size(); i++) {
            long size = inputBlocks.get(i);
            if (size <= 0) throw new IllegalArgumentException("Memory block sizes must be positive.");
            blocks.add(new MemoryBlock(i, size)); remaining.add(size);
        }
        List<Integer> allocation = new ArrayList<>();
        List<Long> used = new ArrayList<>();
        for (int i = 0; i < blocks.size(); i++) used.add(0L);
        long internal = 0, free = 0;
        int allocated = 0;
        for (FragProcess process : processes) {
            if (process.size() <= 0) throw new IllegalArgumentException("Process memory requirements must be positive.");
            int chosen = -1;
            for (int i = 0; i < remaining.size(); i++) {
                if (remaining.get(i) < process.size()) continue;
                if (strategy == Strategy.FIRST_FIT) { chosen = i; break; }
                if (chosen < 0 || (strategy == Strategy.BEST_FIT && remaining.get(i) < remaining.get(chosen))
                        || (strategy == Strategy.WORST_FIT && remaining.get(i) > remaining.get(chosen))) chosen = i;
            }
            allocation.add(chosen);
            if (chosen >= 0) {
                remaining.set(chosen, remaining.get(chosen) - process.size());
                used.set(chosen, Math.addExact(used.get(chosen), process.size()));
                internal = Math.addExact(internal, remaining.get(chosen));
                remaining.set(chosen, 0L);
                allocated++;
            }
        }
        for (long left : remaining) free = Math.addExact(free, left);
        return new FragResult(strategy.toString(), List.copyOf(blocks), List.copyOf(processes),
                List.copyOf(allocation), List.copyOf(used), internal, free, free, allocated,
                processes.size() - allocated);
    }
}
