# Operating System Simulator

A standalone Java Swing desktop application for exploring eight operating-system
algorithms. The application uses only the JDK (Java 17 or newer) and has no
external JAR dependencies.

## Open and run in Visual Studio Code

1. Install JDK 17+ and Visual Studio Code.
2. Open this folder in VS Code. The Java extension pack is recommended; it is
   not a runtime dependency.
3. Use **Terminal → Run Build Task → Build OperatingSystemSimulator.jar**, or run:

   ```powershell
   .\build.ps1
   ```

4. Start the standalone application from the terminal:

   ```powershell
   java -jar OperatingSystemSimulator.jar
   ```

   Or use **Run Build Task → Run Operating System Simulator**.

All simulation inputs can be edited, removed, cleared, pasted, or imported.
Every module includes optional **Load Small Sample** and **Load Large Dataset**
helpers; they are editable examples, not required or locked data. Data tables
accept CSV/TXT imports with one row per line and commas, semicolons, tabs, or
spaces between fields. Plain number-list modules accept comma-, space-, and
newline-separated values.

## Build a standalone executable JAR

Run these commands from the project root in PowerShell:

```powershell
Remove-Item -Recurse -Force out -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force out | Out-Null
$sources = Get-ChildItem -Path src -Recurse -Filter *.java | ForEach-Object { $_.FullName }
javac -encoding UTF-8 -d out $sources
jar cfe OperatingSystemSimulator.jar com.ossimulator.Main -C out .
```

Run it with:

```powershell
java -jar OperatingSystemSimulator.jar
```

The output JAR has no dependency classpath. Large simulations execute with
`SwingWorker`; if the JVM heap is insufficient, increase it, for example:
`java -Xmx4g -jar OperatingSystemSimulator.jar`.

## Modules and algorithms

| Module | Algorithms / behavior |
|---|---|
| CPU Scheduling | FCFS, non-preemptive SJF, preemptive SRTF, non-preemptive and preemptive priority, Round Robin; Gantt chart, completion/turnaround/wait/response times, averages and utilization. Lower priority number means higher priority. |
| Banker's Algorithm | Computes Need = Max − Allocation, performs the safety search, reports a safe sequence or blocked processes, and includes Work/Finish trace rows. |
| Paging | Translates logical addresses using page number, offset, configurable page size, logical-page count and an editable page-to-frame table. `-1` denotes an invalid/not-resident page. |
| Page Replacement | FIFO, LRU and Optimal; frame-state matrix marks hits and faults, rates and counts; includes a compare-all summary. |
| Segmentation | Checks segment existence and `0 <= offset < limit`, returns base + offset, and paints the configured segment ranges. |
| Fragmentation | First Fit, Best Fit and Worst Fit fixed-partition allocation; reports process status, internal waste and unallocated free space. |
| Disk Scheduling | FCFS, SSTF, SCAN, C-SCAN, LOOK and C-LOOK; shows service order, edge/wrap travel, total seek distance and head-movement chart. |
| Multiprogramming | Loads programs as usable RAM permits, tracks resident/I/O/waiting programs per tick, reports peak degree and memory use, and computes CPU utilization as `1 - p^n`. |

### Sample verification

The small sample buttons provide reproducible presentation inputs. For example:

* **CPU / FCFS**: `A(Arrival=0, Burst=5)`, `B(Arrival=2, Burst=3)` yields
  completion times `5, 8`, waiting times `0, 3`, and average waiting `1.5`.
* **Banker**: Allocation `[[0,1,0],[2,0,0],[3,0,2],[2,1,1],[0,0,2]]`,
  Max `[[7,5,3],[3,2,2],[9,0,2],[2,2,2],[4,3,3]]`, Available `[3,3,2]`
  is safe; one sequence is `P1 → P3 → P4 → P0 → P2`.
* **Paging**: with page size `100`, page 0 mapped to frame 2, logical address
  `50` translates to physical address `250`; page 1 mapped to `-1` faults.
* **Page Replacement**: references `1,2,3,1,2` with three FIFO frames produce
  three faults and two hits.
* **Disk / FCFS**: requests `40,10`, head at `20`, produce service order
  `40,10` and `50` cylinders of movement.

Run dependency-free backend checks after compiling:

```powershell
$tests = Get-ChildItem -Path test -Recurse -Filter *.java | ForEach-Object { $_.FullName }
javac -encoding UTF-8 -cp out -d test-out $tests
java -cp "out;test-out" com.ossimulator.AlgorithmSmokeTest
java -Djava.awt.headless=true -cp "out;test-out" com.ossimulator.UiConstructionTest
```

## Project layout

```text
src/com/ossimulator/
  Main.java
  algorithms/       Pure Java simulation logic (no Swing imports)
  model/            Input, trace and result records
  theme/            Modern dark slate and indigo Swing theme
  ui/
    MainFrame.java  Sidebar navigation and CardLayout shell
    components/     Scrollable Gantt, disk, memory and frame charts
    panels/         Eight module panels and shared panel support
  utils/            Validation, CSV/TXT import and SwingWorker helper
test/com/ossimulator/
  AlgorithmSmokeTest.java
.vscode/            VS Code Java settings and build/run tasks
```

Dynamic collections and table models are used for process, frame, page,
resource, segment, block, request and program data. Visual canvases compute
their preferred size from the current input and live inside scroll panes.
Numeric inputs are validated before execution; invalid input is reported in a
friendly dialog instead of being passed to algorithm code.
