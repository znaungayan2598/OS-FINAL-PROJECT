package com.ossimulator.ui.components;

import com.ossimulator.model.ReplacementResult;
import com.ossimulator.theme.ModernTheme;
import javax.swing.*;
import java.awt.*;

/** Draws frame contents and page hits or faults. */
public final class FrameMatrixPanel extends JPanel {
    private ReplacementResult result;
    public FrameMatrixPanel() { setBackground(ModernTheme.CARD); }
    public void setResult(ReplacementResult result) { this.result = result; revalidate(); repaint(); }
    @Override public Dimension getPreferredSize() {
        if (result == null) return new Dimension(760, 150);
        return new Dimension(Math.max(760, result.refs().size() * 54 + 100), Math.max(150, result.frames() * 38 + 75));
    }
    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        if (result == null) return;
        Graphics2D g = (Graphics2D) graphics.create();
        int x0 = 68, y0 = 35, cellW = 48, cellH = 32;
        g.setFont(ModernTheme.SMALL); g.setColor(ModernTheme.TEXT_DIM);
        for (int c = 0; c < result.refs().size(); c++) {
            int x = x0 + c * cellW;
            g.drawString(Integer.toString(result.refs().get(c)), x + 14, y0 - 8);
            for (int r = 0; r < result.frames(); r++) {
                int y = y0 + r * cellH;
                boolean hit = result.hit().get(c);
                g.setColor(hit ? new Color(0x14532D) : new Color(0x7F1D1D));
                g.fillRect(x, y, cellW - 2, cellH - 2);
                g.setColor(ModernTheme.BORDER); g.drawRect(x, y, cellW - 2, cellH - 2);
                Integer page = result.frameStates().get(c).get(r);
                if (page != null) {
                    g.setColor(ModernTheme.TEXT);
                    String text = page.toString(); g.drawString(text, x + (cellW - g.getFontMetrics().stringWidth(text)) / 2, y + 21);
                }
            }
        }
        g.setColor(ModernTheme.TEXT_DIM);
        for (int r = 0; r < result.frames(); r++) g.drawString("F" + r, 18, y0 + r * cellH + 20);
        g.dispose();
    }
}
