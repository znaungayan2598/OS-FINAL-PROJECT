package com.ossimulator.algorithms;

import com.ossimulator.model.PagingRow;
import java.util.ArrayList;
import java.util.List;

/** Translates logical addresses through a page table. */
public final class PagingAlgorithm {
    private PagingAlgorithm() {}

    public static List<PagingRow> translate(long pageSize, long logicalPages, List<Long> pageTable,
                                            List<Long> addresses) {
        if (pageSize <= 0 || logicalPages <= 0) throw new IllegalArgumentException("Page size and logical page count must be positive.");
        if (pageTable.size() != logicalPages) throw new IllegalArgumentException("Page table must contain one entry per logical page.");
        List<PagingRow> rows = new ArrayList<>();
        for (long address : addresses) {
            if (address < 0) throw new IllegalArgumentException("Logical addresses cannot be negative.");
            long page = address / pageSize, offset = address % pageSize;
            if (page >= logicalPages) {
                rows.add(new PagingRow(address, page, offset, null, null, "Invalid logical page", false));
            } else {
                long frame = pageTable.get((int) page);
                if (frame < 0) rows.add(new PagingRow(address, page, offset, null, null, "Page fault: page is not in memory", false));
                else {
                    long physical = Math.addExact(Math.multiplyExact(frame, pageSize), offset);
                    rows.add(new PagingRow(address, page, offset, frame, physical, "Translated", true));
                }
            }
        }
        return List.copyOf(rows);
    }
}
