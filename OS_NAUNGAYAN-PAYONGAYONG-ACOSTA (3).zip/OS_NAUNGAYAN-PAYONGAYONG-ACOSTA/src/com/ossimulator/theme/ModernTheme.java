package com.ossimulator.theme;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Modern dark slate and indigo Swing palette and reusable component styles. */
public final class ModernTheme {
    private ModernTheme() {}
    public static final Color BG = new Color(0x0F172A), SIDEBAR = new Color(0x0B1220);
    public static final Color CARD = new Color(0x1E293B), CARD_ALT = new Color(0x243247);
    public static final Color ROW_ALT = new Color(0x22304A), FIELD = new Color(0x111C31);
    public static final Color BORDER = new Color(0x334155), TEXT = new Color(0xE2E8F0);
    public static final Color TEXT_DIM = new Color(0x94A3B8), INDIGO = new Color(0x6366F1);
    public static final Color INDIGO_DARK = new Color(0x4F46E5), EMERALD = new Color(0x10B981);
    public static final Color CORAL = new Color(0xF87171), AMBER = new Color(0xF59E0B);
    public static final Color IDLE = new Color(0x475569);
    public static final String FONT_FAMILY = Font.SANS_SERIF;
    public static Font font(int style, float size) { return new Font(FONT_FAMILY, style, Math.round(size)); }
    public static final Font BASE = font(Font.PLAIN, 13), BOLD = font(Font.BOLD, 13);
    public static final Font SMALL = font(Font.PLAIN, 12), TITLE = font(Font.BOLD, 22);
    public static final Font MONO = new Font(Font.MONOSPACED, Font.PLAIN, 12);

    public static void install() {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
        catch (Exception e) { throw new IllegalStateException("Unable to initialize Swing look and feel.", e); }
        UIManager.put("Panel.background", BG); UIManager.put("OptionPane.background", CARD);
        UIManager.put("OptionPane.messageForeground", TEXT); UIManager.put("Label.foreground", TEXT);
        UIManager.put("Button.font", BASE); UIManager.put("Table.font", BASE);
        UIManager.put("Table.background", FIELD); UIManager.put("Table.foreground", TEXT);
        UIManager.put("Table.selectionBackground", INDIGO_DARK); UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("ScrollPane.background", CARD); UIManager.put("TextField.background", FIELD);
        UIManager.put("TextField.foreground", TEXT);
        UIManager.put("ComboBox.background", FIELD); UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("ComboBox.selectionBackground", INDIGO_DARK); UIManager.put("ComboBox.selectionForeground", TEXT);
        UIManager.put("ComboBox.border", BorderFactory.createLineBorder(BORDER));
    }
    public static Border cardBorder() {
        return BorderFactory.createCompoundBorder(new LineBorder(BORDER, 1, true),
                BorderFactory.createEmptyBorder(14, 14, 14, 14));
    }
    public static void styleButton(AbstractButton button, boolean primary) {
        button.setFont(BOLD); button.setForeground(TEXT);
        button.setBackground(primary ? INDIGO_DARK : CARD_ALT);
        button.setFocusPainted(false); button.setBorder(BorderFactory.createEmptyBorder(9, 14, 9, 14));
        button.setOpaque(false); button.setContentAreaFilled(false);
        button.setUI(new BasicButtonUI() {
            @Override public void paint(Graphics graphics, JComponent component) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(component.getBackground());
                g.fillRoundRect(0, 0, component.getWidth() - 1, component.getHeight() - 1, 12, 12);
                g.setColor(BORDER);
                g.drawRoundRect(0, 0, component.getWidth() - 1, component.getHeight() - 1, 12, 12);
                g.dispose();
                super.paint(graphics, component);
            }
        });
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        Color normal = button.getBackground();
        button.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { if (button.isEnabled()) button.setBackground(primary ? INDIGO : BORDER); }
            @Override public void mouseExited(MouseEvent e) { button.setBackground(normal); }
        });
    }
    /** Paints a panel with rounded corners. */
    public static final class RoundedPanel extends JPanel {
        public RoundedPanel(LayoutManager layout) { super(layout); setOpaque(false); }
        @Override protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(getBackground());
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g.setColor(BORDER);
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g.dispose();
            super.paintComponent(graphics);
        }
    }
    public static void styleTable(JTable table) {
        table.setBackground(FIELD); table.setForeground(TEXT); table.setGridColor(BORDER);
        table.setSelectionBackground(INDIGO_DARK); table.setSelectionForeground(TEXT);
        table.setRowHeight(28); table.setFillsViewportHeight(true); table.setFont(BASE);
        JTableHeader header = table.getTableHeader();
        header.setBackground(CARD_ALT); header.setForeground(TEXT); header.setFont(BOLD);
        header.setReorderingAllowed(false);
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                                                                     boolean focus, int row, int column) {
                Component c = super.getTableCellRendererComponent(t, value, selected, focus, row, column);
                if (!selected) c.setBackground(row % 2 == 0 ? FIELD : ROW_ALT);
                c.setForeground(TEXT); setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));
                return c;
            }
        };
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++)
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
    }
    public static void styleScrollPane(JScrollPane pane) {
        pane.setBorder(BorderFactory.createLineBorder(BORDER));
        pane.getViewport().setBackground(FIELD);
        java.util.List<JScrollBar> bars = java.util.List.of(pane.getVerticalScrollBar(), pane.getHorizontalScrollBar());
        for (JScrollBar bar : bars) {
            bar.setUI(new BasicScrollBarUI() {
                @Override protected void configureScrollBarColors() { thumbColor = BORDER; trackColor = CARD; }
                @Override protected JButton createDecreaseButton(int orientation) { return zeroButton(); }
                @Override protected JButton createIncreaseButton(int orientation) { return zeroButton(); }
                private JButton zeroButton() { JButton b = new JButton(); b.setPreferredSize(new Dimension(0, 0)); return b; }
            });
        }
    }
}
