package com.ossimulator.model;

/** A contiguous block of CPU time on the Gantt chart. pid is "IDLE" for CPU idle time. */
public record GanttSlice(String pid, long start, long end) {
    public static final String IDLE = "IDLE";

    public boolean idle() { return IDLE.equals(pid); }

    public long length() { return end - start; }
}
