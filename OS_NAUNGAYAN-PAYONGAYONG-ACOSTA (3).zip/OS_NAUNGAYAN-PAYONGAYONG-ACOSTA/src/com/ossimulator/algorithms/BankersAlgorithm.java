package com.ossimulator.algorithms;

import com.ossimulator.model.BankerResult;
import com.ossimulator.model.BankerStep;
import java.util.ArrayList;
import java.util.List;

/** Banker's safety algorithm and an auditable work/finish trace. */
public final class BankersAlgorithm {
    private BankersAlgorithm() {}

    public static List<List<Long>> computeNeed(List<List<Long>> max, List<List<Long>> allocation) {
        validateMatrices(max, allocation);
        List<List<Long>> need = new ArrayList<>();
        for (int i = 0; i < max.size(); i++) {
            List<Long> row = new ArrayList<>();
            for (int j = 0; j < max.get(i).size(); j++) row.add(max.get(i).get(j) - allocation.get(i).get(j));
            need.add(List.copyOf(row));
        }
        return List.copyOf(need);
    }

    public static BankerResult run(List<String> ids, List<List<Long>> allocation,
                                   List<List<Long>> max, List<Long> available) {
        validateMatrices(max, allocation);
        int processCount = allocation.size();
        int resourceCount = available.size();
        if (processCount == 0 || ids.size() != processCount) throw new IllegalArgumentException("Process rows and process IDs must match and cannot be empty.");
        for (int r = 0; r < resourceCount; r++) if (available.get(r) < 0) throw new IllegalArgumentException("Available resource counts cannot be negative.");
        if (max.get(0).size() != resourceCount) throw new IllegalArgumentException("Available vector must have one value per resource type.");
        List<List<Long>> need = computeNeed(max, allocation);
        List<Long> work = new ArrayList<>(available);
        List<Boolean> finish = new ArrayList<>();
        for (int i = 0; i < processCount; i++) finish.add(false);
        List<BankerStep> steps = new ArrayList<>();
        List<String> sequence = new ArrayList<>();
        steps.add(new BankerStep(0, "-", "-", vector(work), vector(work), finish(finish), "Initialise Work = Available"));
        boolean advanced = true;
        while (sequence.size() < processCount && advanced) {
            advanced = false;
            for (int i = 0; i < processCount; i++) {
                if (finish.get(i) || !fits(need.get(i), work)) continue;
                List<Long> before = new ArrayList<>(work);
                for (int r = 0; r < resourceCount; r++) work.set(r, Math.addExact(work.get(r), allocation.get(i).get(r)));
                finish.set(i, true);
                sequence.add(ids.get(i));
                steps.add(new BankerStep(steps.size(), ids.get(i), vector(need.get(i)), vector(before), vector(work),
                        finish(finish), ids.get(i) + " can finish; release its allocation."));
                advanced = true;
            }
        }
        List<String> unfinished = new ArrayList<>();
        for (int i = 0; i < processCount; i++) if (!finish.get(i)) unfinished.add(ids.get(i));
        boolean safe = unfinished.isEmpty();
        if (!safe) steps.add(new BankerStep(steps.size(), "-", "-", vector(work), vector(work), finish(finish),
                "No remaining process can proceed with the current Work vector."));
        return new BankerResult(List.copyOf(ids), need, List.copyOf(steps), safe,
                List.copyOf(sequence), List.copyOf(unfinished));
    }

    private static void validateMatrices(List<List<Long>> max, List<List<Long>> allocation) {
        if (max == null || allocation == null || max.size() != allocation.size() || max.isEmpty())
            throw new IllegalArgumentException("Allocation and Max matrices must have the same non-zero number of process rows.");
        int columns = max.get(0).size();
        if (columns == 0) throw new IllegalArgumentException("Add at least one resource type.");
        for (int i = 0; i < max.size(); i++) {
            if (max.get(i).size() != columns || allocation.get(i).size() != columns)
                throw new IllegalArgumentException("Every matrix row must have the same number of resource columns.");
            for (int j = 0; j < columns; j++) {
                long m = max.get(i).get(j), a = allocation.get(i).get(j);
                if (m < 0 || a < 0) throw new IllegalArgumentException("Resource counts cannot be negative.");
                if (a > m) throw new IllegalArgumentException("Allocation cannot exceed Max (process row " + (i + 1) + ").");
            }
        }
    }
    private static boolean fits(List<Long> need, List<Long> work) {
        for (int i = 0; i < need.size(); i++) if (need.get(i) > work.get(i)) return false;
        return true;
    }
    private static String vector(List<Long> values) { return values.toString(); }
    private static String finish(List<Boolean> values) { return values.toString(); }
}
