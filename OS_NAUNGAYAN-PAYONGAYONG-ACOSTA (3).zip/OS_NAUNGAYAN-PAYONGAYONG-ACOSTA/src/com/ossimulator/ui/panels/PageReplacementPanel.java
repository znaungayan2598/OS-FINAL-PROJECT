package com.ossimulator.ui.panels;

import com.ossimulator.algorithms.PageReplacement;
import com.ossimulator.model.ReplacementResult;
import com.ossimulator.theme.ModernTheme;
import com.ossimulator.ui.components.FrameMatrixPanel;
import com.ossimulator.utils.BulkInput;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/** Provides inputs and results for page replacement. */
public final class PageReplacementPanel extends ModulePanelBase {
    private final JTextArea references = new JTextArea("7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2", 5, 50);
    private final JTextField frames = textField("3", 8);
    private final JComboBox<PageReplacement.Algorithm> algorithm = new JComboBox<>(new Vector<>(List.of(
            PageReplacement.Algorithm.FIFO, PageReplacement.Algorithm.LRU, PageReplacement.Algorithm.OPTIMAL)));
    private final FrameMatrixPanel matrix = new FrameMatrixPanel();
    public PageReplacementPanel() {
        super("Page Replacement", "Visualize FIFO, LRU and Optimal frame contents, hits and faults.");
        references.setBackground(ModernTheme.FIELD); references.setForeground(ModernTheme.TEXT);
        references.setCaretColor(ModernTheme.TEXT); references.setFont(ModernTheme.MONO);
        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4)); form.setOpaque(false);
        form.add(labelField("Physical frames", frames)); form.add(labelField("Algorithm", algorithm));
        JButton runAll = new JButton("Compare All 3 Algorithms"); ModernTheme.styleButton(runAll, false);
        runAll.addActionListener(e -> runAll());
        addTool("Run Selected Algorithm", this::runSimulation, true);
        tools.add(runAll);
        addTool("+ Append Page", this::appendPage, false);
        addTool("- Remove Last Page", this::removeLastPage, false);
        JPanel card = cardPanel("Page reference string");
        card.add(form, BorderLayout.NORTH);
        JScrollPane inputScroll = new JScrollPane(references); ModernTheme.styleScrollPane(inputScroll);
        card.add(inputScroll, BorderLayout.CENTER);
        JLabel hint = new JLabel("Paste comma-, space-, or newline-separated non-negative page numbers.");
        hint.setForeground(ModernTheme.TEXT_DIM); hint.setFont(ModernTheme.SMALL);
        card.add(hint, BorderLayout.SOUTH); input.add(card, BorderLayout.CENTER);
    }
    private void appendPage() {
        String value = JOptionPane.showInputDialog(this, "Page number to append:", "Append Page", JOptionPane.QUESTION_MESSAGE);
        if (value == null) return;
        try {
            long page = InputValidator.parseLong(value, "Page number", 0, Integer.MAX_VALUE);
            String current = references.getText().trim();
            references.setText(current.isEmpty() ? Long.toString(page) : current + ", " + page);
        } catch (InputValidator.InvalidInputException e) { showWarning(e); }
    }
    private void removeLastPage() {
        try {
            List<Integer> values = parsedReferences();
            if (!values.isEmpty()) values.remove(values.size() - 1);
            references.setText(values.toString().replace("[", "").replace("]", ""));
        } catch (InputValidator.InvalidInputException e) {
            if (references.getText().trim().isEmpty()) return;
            showWarning(e);
        }
    }
    private List<Integer> parsedReferences() throws InputValidator.InvalidInputException {
        List<Long> values = InputValidator.parseLongList(references.getText(), "Page reference", 0);
        List<Integer> parsed = new ArrayList<>();
        for (long value : values) {
            if (value > Integer.MAX_VALUE) throw new InputValidator.InvalidInputException("Page reference exceeds the supported integer range.");
            parsed.add((int) value);
        }
        return parsed;
    }
    @Override protected void runSimulation() {
        try {
            int frameCount = InputValidator.parseInt(frames.getText(), "Frame count", 1, Integer.MAX_VALUE);
            PageReplacement.Algorithm selected = (PageReplacement.Algorithm) algorithm.getSelectedItem();
            List<Integer> values = parsedReferences();
            runTyped(() -> PageReplacement.run(values, frameCount, selected), this::render);
        } catch (Exception e) { showWarning(e); }
    }
    private void runAll() {
        try {
            int frameCount = InputValidator.parseInt(frames.getText(), "Frame count", 1, Integer.MAX_VALUE);
            List<Integer> values = parsedReferences();
            runTyped(() -> {
                List<ReplacementResult> results = new ArrayList<>();
                for (PageReplacement.Algorithm item : PageReplacement.Algorithm.values())
                    results.add(PageReplacement.run(values, frameCount, item));
                return results;
            }, results -> {
                StringBuilder summary = new StringBuilder("Algorithm comparison\n");
                for (ReplacementResult result : results) summary.append(result.algorithm()).append(": ")
                        .append(result.hits()).append(" hits, ").append(result.faults()).append(" faults (")
                        .append(String.format("%.2f%% hit rate", result.hitRate())).append(")\n");
                matrix.setResult(results.get(0));
                showOutput(summary + "\nThe visual matrix shows the FIFO run.", matrix);
            });
        } catch (Exception e) { showWarning(e); }
    }
    private void render(ReplacementResult result) {
        matrix.setResult(result);
        String text = result.algorithm() + "\nReferences: " + result.refs().size()
                + "\nPage hits: " + result.hits() + "\nPage faults: " + result.faults()
                + String.format("\nHit rate: %.2f%%\nFault rate: %.2f%%", result.hitRate(), result.faultRate());
        showOutput(text, matrix);
    }
    @Override protected void loadSample(boolean large) {
        List<Integer> values = new ArrayList<>();
        int count = large ? 60 : 5;
        for (int i = 0; i < count; i++) values.add(large ? (i * 7 + i / 3) % 13 : List.of(1, 2, 3, 1, 2).get(i));
        references.setText(values.toString().replace("[", "").replace("]", ""));
        frames.setText(large ? "5" : "3");
    }
    @Override protected void clearData() { references.setText(""); frames.setText("3"); output.setText(""); matrix.setResult(null); }
    @Override protected JTable importTable() { return null; }
    @Override protected void importData() {
        java.io.File file = BulkInput.chooseFile(this);
        if (file == null) return;
        try { references.setText(BulkInput.readFile(file)); }
        catch (IOException e) { showWarning(e); }
    }
}
