package com.ossimulator.algorithms;

import com.ossimulator.model.CpuResult;
import com.ossimulator.model.GanttSlice;
import com.ossimulator.model.ProcessInfo;
import com.ossimulator.model.ProcessStats;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Event-driven CPU scheduling algorithms. This class has no Swing dependencies. */
public final class CpuScheduler {
    private CpuScheduler() {}

    /** Lists the supported disk scheduling algorithms. */
    public enum Algorithm {
        FCFS("FCFS"), SJF("SJF (Non-Preemptive)"), SRTF("SRTF (Preemptive SJF)"),
        PRIORITY_NP("Priority (Non-Preemptive)"), PRIORITY_P("Priority (Preemptive)"),
        ROUND_ROBIN("Round Robin");
        private final String label;
        Algorithm(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    /** Tracks mutable execution state for one CPU process. */
    private static final class Job {
        final int index;
        final ProcessInfo process;
        long remaining;
        long firstStart = -1;
        long completion = -1;
        Job(int index, ProcessInfo process) {
            this.index = index;
            this.process = process;
            remaining = process.burst();
        }
    }

    public static CpuResult run(List<ProcessInfo> input, Algorithm algorithm, long quantum) {
        if (input == null || input.isEmpty()) throw new IllegalArgumentException("Add at least one process.");
        if (algorithm == null) throw new IllegalArgumentException("Choose a scheduling algorithm.");
        if (algorithm == Algorithm.ROUND_ROBIN && quantum <= 0)
            throw new IllegalArgumentException("Time quantum must be greater than zero.");
        List<Job> jobs = new ArrayList<>();
        for (int i = 0; i < input.size(); i++) {
            ProcessInfo p = input.get(i);
            if (p.arrival() < 0 || p.burst() <= 0) throw new IllegalArgumentException("Arrival must be non-negative and burst must be positive.");
            jobs.add(new Job(i, p));
        }
        List<GanttSlice> gantt = new ArrayList<>();
        switch (algorithm) {
            case FCFS -> nonPreemptive(jobs, gantt, Comparator.comparingLong((Job j) -> j.process.arrival()).thenComparingInt(j -> j.index));
            case SJF -> nonPreemptive(jobs, gantt, Comparator.comparingLong((Job j) -> j.process.burst()).thenComparingLong(j -> j.process.arrival()).thenComparingInt(j -> j.index));
            case PRIORITY_NP -> nonPreemptive(jobs, gantt, Comparator.comparingInt((Job j) -> j.process.priority()).thenComparingLong(j -> j.process.arrival()).thenComparingInt(j -> j.index));
            case SRTF -> preemptive(jobs, gantt, Comparator.comparingLong((Job j) -> j.remaining).thenComparingLong(j -> j.process.arrival()).thenComparingInt(j -> j.index));
            case PRIORITY_P -> preemptive(jobs, gantt, Comparator.comparingInt((Job j) -> j.process.priority()).thenComparingLong(j -> j.process.arrival()).thenComparingInt(j -> j.index));
            case ROUND_ROBIN -> roundRobin(jobs, gantt, quantum);
        }
        return result(algorithm, jobs, gantt);
    }

    private static void nonPreemptive(List<Job> jobs, List<GanttSlice> out, Comparator<Job> order) {
        List<Job> remaining = new ArrayList<>(jobs);
        long now = 0;
        while (!remaining.isEmpty()) {
            Job chosen = null;
            for (Job job : remaining)
                if (job.process.arrival() <= now && (chosen == null || order.compare(job, chosen) < 0)) chosen = job;
            if (chosen == null) {
                long next = remaining.stream().mapToLong(j -> j.process.arrival()).min().orElse(now);
                append(out, GanttSlice.IDLE, now, next);
                now = next;
                continue;
            }
            chosen.firstStart = now;
            long end = Math.addExact(now, chosen.remaining);
            append(out, chosen.process.id(), now, end);
            chosen.remaining = 0;
            chosen.completion = end;
            now = end;
            remaining.remove(chosen);
        }
    }

    private static void preemptive(List<Job> jobs, List<GanttSlice> out, Comparator<Job> order) {
        long now = 0;
        int completed = 0;
        while (completed < jobs.size()) {
            Job chosen = null;
            for (Job job : jobs)
                if (job.remaining > 0 && job.process.arrival() <= now && (chosen == null || order.compare(job, chosen) < 0))
                    chosen = job;
            if (chosen == null) {
                long next = jobs.stream().filter(j -> j.remaining > 0).mapToLong(j -> j.process.arrival()).min().orElse(now);
                append(out, GanttSlice.IDLE, now, next);
                now = next;
                continue;
            }
            if (chosen.firstStart < 0) chosen.firstStart = now;
            long nextArrival = Long.MAX_VALUE;
            for (Job job : jobs)
                if (job.remaining > 0 && job.process.arrival() > now) nextArrival = Math.min(nextArrival, job.process.arrival());
            long end = Math.min(Math.addExact(now, chosen.remaining), nextArrival);
            if (end <= now) end = Math.addExact(now, 1);
            long elapsed = end - now;
            chosen.remaining -= elapsed;
            append(out, chosen.process.id(), now, end);
            now = end;
            if (chosen.remaining == 0) {
                chosen.completion = now;
                completed++;
            }
        }
    }

    private static void roundRobin(List<Job> jobs, List<GanttSlice> out, long quantum) {
        List<Job> arrivals = new ArrayList<>(jobs);
        arrivals.sort(Comparator.comparingLong((Job j) -> j.process.arrival()).thenComparingInt(j -> j.index));
        List<Job> queue = new ArrayList<>();
        long now = 0;
        int cursor = 0, completed = 0;
        while (completed < jobs.size()) {
            while (cursor < arrivals.size() && arrivals.get(cursor).process.arrival() <= now) queue.add(arrivals.get(cursor++));
            if (queue.isEmpty()) {
                long next = arrivals.get(cursor).process.arrival();
                append(out, GanttSlice.IDLE, now, next);
                now = next;
                continue;
            }
            Job job = queue.remove(0);
            if (job.firstStart < 0) job.firstStart = now;
            long end = Math.addExact(now, Math.min(quantum, job.remaining));
            job.remaining -= end - now;
            append(out, job.process.id(), now, end);
            now = end;
            while (cursor < arrivals.size() && arrivals.get(cursor).process.arrival() <= now) queue.add(arrivals.get(cursor++));
            if (job.remaining == 0) {
                job.completion = now;
                completed++;
            } else queue.add(job);
        }
    }

    private static void append(List<GanttSlice> out, String pid, long start, long end) {
        if (end <= start) return;
        if (!out.isEmpty()) {
            GanttSlice previous = out.get(out.size() - 1);
            if (previous.pid().equals(pid) && previous.end() == start) {
                out.set(out.size() - 1, new GanttSlice(pid, previous.start(), end));
                return;
            }
        }
        out.add(new GanttSlice(pid, start, end));
    }

    private static CpuResult result(Algorithm algorithm, List<Job> jobs, List<GanttSlice> gantt) {
        List<ProcessStats> stats = new ArrayList<>();
        double wait = 0, turnaround = 0;
        long busy = 0, first = Long.MAX_VALUE, end = 0;
        for (Job j : jobs) {
            long tat = j.completion - j.process.arrival();
            long waiting = tat - j.process.burst();
            stats.add(new ProcessStats(j.process.id(), j.process.arrival(), j.process.burst(), j.process.priority(),
                    j.completion, tat, waiting, j.firstStart - j.process.arrival()));
            wait += waiting;
            turnaround += tat;
            first = Math.min(first, j.process.arrival());
            end = Math.max(end, j.completion);
            busy = Math.addExact(busy, j.process.burst());
        }
        double utilization = end == first ? 0 : 100.0 * busy / (end - first);
        return new CpuResult(algorithm.toString(), List.copyOf(gantt), List.copyOf(stats),
                wait / jobs.size(), turnaround / jobs.size(), utilization);
    }
}
