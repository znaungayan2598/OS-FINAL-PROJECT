package com.ossimulator.algorithms;

import com.ossimulator.model.DiskMove;
import com.ossimulator.model.DiskResult;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Implements disk scheduling algorithms. */
public final class DiskScheduler {
    private DiskScheduler() {}
    /** Lists the supported disk scheduling algorithms. */
    public enum Algorithm {
        FCFS("FCFS"), SSTF("SSTF"), SCAN("SCAN"), C_SCAN("C-SCAN"), LOOK("LOOK"), C_LOOK("C-LOOK");
        private final String label;
        Algorithm(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }
    /** Describes the disk-head travel direction. */
    public enum Direction {
        UP("Toward Higher Cylinders"), DOWN("Toward Lower Cylinders");
        private final String label;
        Direction(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    public static DiskResult run(List<Long> requests, long head, long min, long max,
                                 Direction direction, Algorithm algorithm) {
        if (requests == null || requests.isEmpty()) throw new IllegalArgumentException("Add at least one disk request.");
        if (min < 0 || max < min || head < min || head > max) throw new IllegalArgumentException("Head and disk limits must be valid; head must be within the disk.");
        for (long request : requests) if (request < min || request > max)
            throw new IllegalArgumentException("Request " + request + " is outside the disk cylinder limits.");
        List<Long> pending = new ArrayList<>(requests), order = new ArrayList<>();
        List<DiskMove> moves = new ArrayList<>();
        long position = head, total = 0;
        if (algorithm == Algorithm.FCFS) {
            for (long request : pending) {
                total = move(position, request, DiskMove.SERVICE, order, moves, total);
                position = request;
            }
        } else if (algorithm == Algorithm.SSTF) {
            while (!pending.isEmpty()) {
                long current = position;
                long next = pending.stream().min((a, b) -> {
                    int c = Long.compare(distance(current, a), distance(current, b));
                    return c != 0 ? c : Long.compare(a, b);
                }).orElseThrow();
                pending.remove(Long.valueOf(next));
                total = move(position, next, DiskMove.SERVICE, order, moves, total);
                position = next;
            }
        } else {
            List<Long> low = new ArrayList<>(), high = new ArrayList<>();
            for (long request : pending) (request < head ? low : high).add(request);
            Collections.sort(low); Collections.sort(high);
            boolean up = direction == Direction.UP;
            if (algorithm == Algorithm.SCAN || algorithm == Algorithm.C_SCAN) {
                if (up) {
                    total = serviceList(high, position, order, moves, total); position = lastOr(high, position);
                    if (!low.isEmpty()) {
                        total = move(position, max, DiskMove.EDGE, order, moves, total); position = max;
                        if (algorithm == Algorithm.C_SCAN) { total = move(position, min, DiskMove.JUMP, order, moves, total); position = min; }
                        else Collections.reverse(low);
                        total = serviceList(low, position, order, moves, total); position = lastOr(low, position);
                    }
                } else {
                    Collections.reverse(low);
                    if (algorithm == Algorithm.C_SCAN) Collections.reverse(high);
                    total = serviceList(low, position, order, moves, total); position = lastOr(low, position);
                    if (!high.isEmpty()) {
                        total = move(position, min, DiskMove.EDGE, order, moves, total); position = min;
                        if (algorithm == Algorithm.C_SCAN) { total = move(position, max, DiskMove.JUMP, order, moves, total); position = max; }
                        total = serviceList(high, position, order, moves, total); position = lastOr(high, position);
                    }
                }
            } else if (algorithm == Algorithm.LOOK) {
                if (up) {
                    total = serviceList(high, position, order, moves, total); position = lastOr(high, position);
                    Collections.reverse(low); total = serviceList(low, position, order, moves, total);
                } else {
                    Collections.reverse(low); total = serviceList(low, position, order, moves, total); position = lastOr(low, position);
                    Collections.reverse(high);
                    total = serviceList(high, position, order, moves, total);
                }
            } else {
                if (up) {
                    total = serviceList(high, position, order, moves, total);
                    if (!low.isEmpty()) {
                        long lastHigh = lastOr(high, position);
                        long firstLow = low.get(0);
                        total = move(lastHigh, firstLow, DiskMove.JUMP, order, moves, total);
                        total = serviceList(low, firstLow, order, moves, total);
                    }
                } else {
                    Collections.reverse(low);
                    total = serviceList(low, position, order, moves, total);
                    if (!high.isEmpty()) {
                        long lastLow = lastOr(low, position);
                        Collections.reverse(high);
                        long firstHigh = high.get(0);
                        total = move(lastLow, firstHigh, DiskMove.JUMP, order, moves, total);
                        total = serviceList(high, firstHigh, order, moves, total);
                    }
                }
            }
        }
        return new DiskResult(algorithm.toString(), List.copyOf(order), List.copyOf(moves), total, head, min, max);
    }
    private static long distance(long a, long b) { return Math.abs(a - b); }
    private static long move(long from, long to, String kind, List<Long> order, List<DiskMove> moves, long total) {
        long d = distance(from, to);
        moves.add(new DiskMove(from, to, d, kind));
        if (DiskMove.SERVICE.equals(kind)) order.add(to);
        return Math.addExact(total, d);
    }
    private static long serviceList(List<Long> values, long position, List<Long> order, List<DiskMove> moves, long total) {
        for (long value : values) {
            long d = distance(position, value);
            moves.add(new DiskMove(position, value, d, DiskMove.SERVICE));
            order.add(value); total = Math.addExact(total, d); position = value;
        }
        return total;
    }
    private static long lastOr(List<Long> values, long fallback) { return values.isEmpty() ? fallback : values.get(values.size() - 1); }
}
