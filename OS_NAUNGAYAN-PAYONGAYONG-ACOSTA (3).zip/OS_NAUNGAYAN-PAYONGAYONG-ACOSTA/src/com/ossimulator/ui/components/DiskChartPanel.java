package com.ossimulator.ui.components;

import com.ossimulator.model.DiskMove;
import com.ossimulator.model.DiskResult;
import com.ossimulator.theme.ModernTheme;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Draws disk-head movement across cylinder positions. */
public final class DiskChartPanel extends JPanel {
    private DiskResult result;
    public DiskChartPanel() { setBackground(ModernTheme.CARD); }
    public void setResult(DiskResult result) { this.result = result; revalidate(); repaint(); }
    @Override public Dimension getPreferredSize() {
        int count = result == null ? 1 : result.moves().size() + 1;
        return new Dimension(Math.max(760, count * 54 + 70), 260);
    }
    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        if (result == null) return;
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int left = 38, right = getWidth() - 24, top = 24, bottom = getHeight() - 35;
        long range = Math.max(1, result.max() - result.min());
        g.setColor(ModernTheme.BORDER); g.drawLine(left, top, left, bottom); g.drawLine(left, bottom, right, bottom);
        List<Long> points = new java.util.ArrayList<>(); points.add(result.head());
        for (DiskMove move : result.moves()) points.add(move.to());
        int prevX = left;
        int prevY = bottom - (int) ((points.get(0) - result.min()) * (bottom - top) / (double) range);
        g.setColor(ModernTheme.INDIGO);
        for (int i = 0; i < points.size(); i++) {
            int x = left + (int) ((right - left) * i / (double) Math.max(1, points.size() - 1));
            int y = bottom - (int) ((points.get(i) - result.min()) * (bottom - top) / (double) range);
            if (i > 0) g.drawLine(prevX, prevY, x, y);
            g.fillOval(x - 4, y - 4, 8, 8);
            g.setColor(ModernTheme.TEXT_DIM); g.setFont(ModernTheme.SMALL);
            g.drawString(Long.toString(points.get(i)), x - 12, y - 8);
            prevX = x; prevY = y; g.setColor(ModernTheme.INDIGO);
        }
        g.setColor(ModernTheme.TEXT_DIM); g.drawString("Service step →", Math.max(left, right - 90), getHeight() - 8);
        g.rotate(-Math.PI / 2); g.drawString("Cylinder", -getHeight() / 2, 14); g.dispose();
    }
}
