package com.ossimulator.utils;

import javax.swing.*;
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

/** Shared parsing and user-facing validation helpers. */
public final class InputValidator {
    private InputValidator() {}
    /** Represents an input error suitable for display. */
    public static final class InvalidInputException extends Exception {
        public InvalidInputException(String message) { super(message); }
    }

    public static void warn(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Please check your input", JOptionPane.WARNING_MESSAGE);
    }
    public static void info(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }
    public static boolean confirm(Component parent, String title, String message) {
        return JOptionPane.showConfirmDialog(parent, message, title, JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }
    public static void showFailure(Component parent, Throwable error) {
        Throwable cause = error instanceof java.util.concurrent.ExecutionException && error.getCause() != null
                ? error.getCause() : error;
        if (cause instanceof OutOfMemoryError) {
            JOptionPane.showMessageDialog(parent,
                    "The data set exceeds the available Java memory. Restart with more memory, for example: java -Xmx4g -jar OperatingSystemSimulator.jar",
                    "Insufficient memory", JOptionPane.ERROR_MESSAGE);
        } else if (cause instanceof InvalidInputException || cause instanceof IllegalArgumentException
                || cause instanceof ArithmeticException) {
            warn(parent, cause.getMessage() == null ? "The input is outside the supported numeric range." : cause.getMessage());
        } else {
            String message = cause.getMessage() == null ? cause.getClass().getSimpleName() : cause.getMessage();
            JOptionPane.showMessageDialog(parent, "The simulation could not be completed:\n" + message,
                    "Simulation error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static long parseLong(String raw, String field, long min, long max) throws InvalidInputException {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) throw new InvalidInputException(field + " is required.");
        final long value;
        try { value = Long.parseLong(text); }
        catch (NumberFormatException e) { throw new InvalidInputException(field + " must be a whole number."); }
        if (value < min || value > max) throw new InvalidInputException(field + " must be between " + min + " and " + max + ".");
        return value;
    }
    public static int parseInt(String raw, String field, int min, int max) throws InvalidInputException {
        long value = parseLong(raw, field, min, max);
        if (value > Integer.MAX_VALUE) throw new InvalidInputException(field + " is too large.");
        return (int) value;
    }
    public static double parseDouble(String raw, String field, double min, double max) throws InvalidInputException {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) throw new InvalidInputException(field + " is required.");
        final double value;
        try { value = Double.parseDouble(text); }
        catch (NumberFormatException e) { throw new InvalidInputException(field + " must be numeric."); }
        if (!Double.isFinite(value) || value < min || value > max)
            throw new InvalidInputException(field + " must be between " + min + " and " + max + ".");
        return value;
    }
    public static List<Long> parseLongList(String raw, String field, long min) throws InvalidInputException {
        List<Long> result = new ArrayList<>();
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) throw new InvalidInputException(field + " cannot be empty.");
        for (String token : text.split("[,;\\s]+")) result.add(parseLong(token, field, min, Long.MAX_VALUE));
        return result;
    }
}
