package com.ossimulator.ui.panels;

import com.ossimulator.algorithms.BankersAlgorithm;
import com.ossimulator.model.BankerResult;
import com.ossimulator.model.BankerStep;
import com.ossimulator.theme.ModernTheme;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.HashSet;
import java.util.Set;

/** Provides inputs and results for Bankers algorithm. */
public final class BankerPanel extends ModulePanelBase {
    private final JTextField processCount = textField("5", 6), resourceCount = textField("3", 6);
    private final JTextField available = textField("", 35);
    private JTable allocation = new JTable(), max = new JTable();
    private DefaultTableModel allocationModel, maxModel;

    /** Builds the matrix editor and Banker's algorithm controls. */
    public BankerPanel() {
        super("Banker's Algorithm", "Resize resource matrices, inspect Need and follow every Work/Finish safety step.");
        JPanel settings = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3)); settings.setOpaque(false);
        settings.add(labelField("Processes (P)", processCount)); settings.add(labelField("Resource types (R)", resourceCount));
        JButton generate = new JButton("Generate Matrices"); ModernTheme.styleButton(generate, false);
        generate.addActionListener(e -> generateMatrices());
        settings.add(generate); settings.add(labelField("Available vector (comma-separated)", available));
        addTool("Run Safety Check", this::runSimulation, true);
        addTool("+ Process", this::addProcessRow, false);
        addTool("- Process", this::removeProcessRow, false);
        addTool("+ Resource", this::addResourceColumn, false);
        addTool("- Resource", this::removeResourceColumn, false);
        JPanel matrixCards = new JPanel(new GridLayout(1, 2, 8, 0)); matrixCards.setOpaque(false);
        JPanel allocCard = cardPanel("Allocation matrix"), maxCard = cardPanel("Maximum demand matrix");
        allocCard.add(tableScroll(allocation), BorderLayout.CENTER); maxCard.add(tableScroll(max), BorderLayout.CENTER);
        matrixCards.add(allocCard); matrixCards.add(maxCard);
        JPanel content = new JPanel(new BorderLayout(8, 8)); content.setOpaque(false);
        content.add(settings, BorderLayout.NORTH); content.add(matrixCards, BorderLayout.CENTER);
        input.add(content, BorderLayout.CENTER);
        generateMatrices();
    }
    /** Adds a matching process row to the Allocation and Max matrices. */
    private void addProcessRow() {
        Vector<Object> alloc = new Vector<>(), maximum = new Vector<>();
        int next = allocationModel.getRowCount();
        alloc.add("P" + next); maximum.add("P" + next);
        for (int i = 1; i < allocationModel.getColumnCount(); i++) { alloc.add(""); maximum.add(""); }
        allocationModel.addRow(alloc); maxModel.addRow(maximum);
        processCount.setText(Integer.toString(allocationModel.getRowCount()));
    }
    /** Removes the final process from both matrices while keeping one row. */
    private void removeProcessRow() {
        if (allocationModel.getRowCount() <= 1) return;
        allocationModel.removeRow(allocationModel.getRowCount() - 1);
        maxModel.removeRow(maxModel.getRowCount() - 1);
        processCount.setText(Integer.toString(allocationModel.getRowCount()));
    }
    /** Adds a resource column to both matrices and updates the resource count. */
    private void addResourceColumn() {
        int index = allocationModel.getColumnCount();
        allocationModel.addColumn("R" + (index - 1));
        maxModel.addColumn("R" + (index - 1));
        for (int row = 0; row < allocationModel.getRowCount(); row++) {
            allocationModel.setValueAt("", row, index); maxModel.setValueAt("", row, index);
        }
        resourceCount.setText(Integer.toString(index));
        available.setText("");
        ModernTheme.styleTable(allocation); ModernTheme.styleTable(max);
    }
    /** Removes the last resource column while keeping at least one resource. */
    private void removeResourceColumn() {
        if (allocationModel.getColumnCount() <= 2) return;
        allocationModel.setColumnCount(allocationModel.getColumnCount() - 1);
        maxModel.setColumnCount(maxModel.getColumnCount() - 1);
        resourceCount.setText(Integer.toString(allocationModel.getColumnCount() - 1));
        available.setText("");
        ModernTheme.styleTable(allocation); ModernTheme.styleTable(max);
    }

    /** Creates editable Allocation and Max matrices using the selected dimensions. */
    private void generateMatrices() {
        try {
            int p = InputValidator.parseInt(processCount.getText(), "Process count", 1, Integer.MAX_VALUE);
            int r = InputValidator.parseInt(resourceCount.getText(), "Resource type count", 1, Integer.MAX_VALUE);
            Vector<String> columns = new Vector<>(); columns.add("Process");
            for (int j = 0; j < r; j++) columns.add("R" + j);
            allocationModel = new DefaultTableModel(new Vector<>(), columns);
            maxModel = new DefaultTableModel(new Vector<>(), new Vector<>(columns));
            for (int i = 0; i < p; i++) {
                Vector<Object> allocRow = new Vector<>(), maxRow = new Vector<>();
                allocRow.add("P" + i); maxRow.add("P" + i);
                for (int j = 0; j < r; j++) { allocRow.add(""); maxRow.add(""); }
                allocationModel.addRow(allocRow); maxModel.addRow(maxRow);
            }
            allocation.setModel(allocationModel); max.setModel(maxModel);
            ModernTheme.styleTable(allocation); ModernTheme.styleTable(max);
            available.setText("");
            setImportTarget(allocation);
        } catch (Exception e) { showWarning(e); }
    }
    /** Fills both matrices and Available with the selected optional sample dataset. */
    private void loadMatrices(boolean large) {
        int p = large ? 35 : 5, r = large ? 6 : 3;
        processCount.setText(Integer.toString(p)); resourceCount.setText(Integer.toString(r));
        generateMatrices();
        for (int i = 0; i < p; i++) for (int j = 0; j < r; j++) {
            long a = large ? (i + j) % 4 : List.of(List.of(0L, 1L, 0L), List.of(2L, 0L, 0L),
                    List.of(3L, 0L, 2L), List.of(2L, 1L, 1L), List.of(0L, 0L, 2L)).get(i).get(j);
            long m = large ? a + 1 + (i * 3L + j) % 5 : List.of(List.of(7L, 5L, 3L), List.of(3L, 2L, 2L),
                    List.of(9L, 0L, 2L), List.of(2L, 2L, 2L), List.of(4L, 3L, 3L)).get(i).get(j);
            allocationModel.setValueAt(a, i, j + 1); maxModel.setValueAt(m, i, j + 1);
        }
        available.setText(large ? "10, 8, 7, 9, 8, 7" : "3, 3, 2");
    }
    /** Loads the requested small or large sample into the matrix editor. */
    @Override protected void loadSample(boolean large) { loadMatrices(large); }
    /** Clears matrix values and the Available vector without changing matrix dimensions. */
    @Override protected void clearData() {
        for (int i = 0; i < allocationModel.getRowCount(); i++)
            for (int j = 1; j < allocationModel.getColumnCount(); j++) allocationModel.setValueAt("", i, j);
        for (int i = 0; i < maxModel.getRowCount(); i++)
            for (int j = 1; j < maxModel.getColumnCount(); j++) maxModel.setValueAt("", i, j);
        available.setText(""); output.setText("");
    }
    /** Returns the default table used by the shared import controls. */
    @Override protected JTable importTable() { return allocation; }
    /** Lets the user choose a matrix and imports its CSV rows. */
    @Override protected void importData() {
        JTable target = chooseImportTable(List.of("Allocation matrix", "Maximum demand matrix"),
                List.of(allocation, max));
        if (target != null) importIntoTable(target);
    }
    /** Validates the matrices and runs the safety algorithm off the UI thread. */
    @Override protected void runSimulation() {
        try {
            List<String> ids = new ArrayList<>();
            Set<String> uniqueIds = new HashSet<>();
            List<List<Long>> alloc = new ArrayList<>(), maximum = new ArrayList<>();
            for (int i = 0; i < allocationModel.getRowCount(); i++) {
                String id = cell(allocation, i, 0, "Process ID");
                if (!uniqueIds.add(id)) throw new InputValidator.InvalidInputException("Process IDs must be unique: " + id + ".");
                ids.add(id);
                List<Long> aRow = new ArrayList<>(), mRow = new ArrayList<>();
                for (int j = 1; j < allocationModel.getColumnCount(); j++) {
                    aRow.add(InputValidator.parseLong(cell(allocation, i, j, "Allocation"), "Allocation", 0, Long.MAX_VALUE));
                    mRow.add(InputValidator.parseLong(cell(max, i, j, "Max"), "Maximum demand", 0, Long.MAX_VALUE));
                }
                alloc.add(aRow); maximum.add(mRow);
            }
            List<Long> availableVector = InputValidator.parseLongList(available.getText(), "Available vector", 0);
            if (availableVector.size() != allocationModel.getColumnCount() - 1)
                throw new InputValidator.InvalidInputException("Available vector needs one number for each resource type.");
            runTyped(() -> BankersAlgorithm.run(ids, alloc, maximum, availableVector), this::render);
        } catch (Exception e) { showWarning(e); }
    }
    /** Displays the safety result, Need matrix, trace, and safe-state banner. */
    private void render(BankerResult result) {
        StringBuilder text = new StringBuilder(result.safe() ? "✅ SAFE STATE\n" : "⚠ UNSAFE STATE\n");
        text.append("Safe sequence: ").append(result.safe() ? String.join(" → ", result.safeSequence()) : "No complete safe sequence")
                .append("\n\nNeed matrix:\n");
        for (int i = 0; i < result.need().size(); i++) text.append(result.processIds().get(i))
                .append(": ").append(result.need().get(i)).append('\n');
        text.append("\nStep | Process | Need | Work before → after | Finish | Detail\n");
        for (BankerStep step : result.steps()) text.append(step.step()).append(" | ").append(step.process()).append(" | ")
                .append(step.need()).append(" | ").append(step.workBefore()).append(" → ").append(step.workAfter())
                .append(" | ").append(step.finish()).append(" | ").append(step.note()).append('\n');
        if (!result.unfinished().isEmpty()) text.append("\nBlocked processes: ").append(result.unfinished());
        showOutput(text.toString());
        JLabel banner = new JLabel(result.safe()
                ? "SAFE — " + String.join(" → ", result.safeSequence())
                : "UNSAFE — blocked: " + String.join(", ", result.unfinished()));
        banner.setOpaque(true);
        banner.setBackground(result.safe() ? new Color(0x065F46) : new Color(0x7F1D1D));
        banner.setForeground(ModernTheme.TEXT);
        banner.setFont(ModernTheme.font(Font.BOLD, 16));
        banner.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        resultHost.add(banner, BorderLayout.NORTH);
        resultHost.revalidate();
    }
}
