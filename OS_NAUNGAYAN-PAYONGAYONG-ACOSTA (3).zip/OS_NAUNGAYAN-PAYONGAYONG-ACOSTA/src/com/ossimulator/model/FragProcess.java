package com.ossimulator.model;

/** A process requesting memory in the fragmentation module. */
public record FragProcess(String id, long size) {
}
