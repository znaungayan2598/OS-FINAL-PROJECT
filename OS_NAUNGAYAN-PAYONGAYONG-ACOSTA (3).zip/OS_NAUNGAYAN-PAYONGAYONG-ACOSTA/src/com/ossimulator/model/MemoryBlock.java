package com.ossimulator.model;

/** A fixed memory partition. */
public record MemoryBlock(int index, long size) {
}
