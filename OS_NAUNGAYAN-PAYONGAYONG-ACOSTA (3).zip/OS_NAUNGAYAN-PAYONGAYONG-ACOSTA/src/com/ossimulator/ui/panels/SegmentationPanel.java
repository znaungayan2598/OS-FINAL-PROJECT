package com.ossimulator.ui.panels;

import com.ossimulator.algorithms.SegmentationAlgorithm;
import com.ossimulator.model.SegmentEntry;
import com.ossimulator.model.SegmentQuery;
import com.ossimulator.model.SegmentResult;
import com.ossimulator.theme.ModernTheme;
import com.ossimulator.ui.components.MemoryMapPanel;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/** Provides inputs and results for segmentation. */
public final class SegmentationPanel extends ModulePanelBase {
    private final DefaultTableModel segmentModel = model(List.of("Segment #", "Base Address", "Limit"));
    private final DefaultTableModel queryModel = model(List.of("Segment #", "Offset"));
    private final JTable segments = new JTable(segmentModel), queries = new JTable(queryModel);
    private final MemoryMapPanel map = new MemoryMapPanel();
    public SegmentationPanel() {
        super("Segmentation", "Translate (segment, offset) addresses and inspect the process memory map.");
        JPanel segmentCard = cardPanel("Segment table"), queryCard = cardPanel("Logical address queries");
        segmentCard.add(tableScroll(segments), BorderLayout.CENTER);
        segmentCard.add(rowButtons(segments, "Segment", this::addSegment), BorderLayout.SOUTH);
        queryCard.add(tableScroll(queries), BorderLayout.CENTER);
        queryCard.add(rowButtons(queries, "Query", this::addQuery), BorderLayout.SOUTH);
        JPanel two = new JPanel(new GridLayout(1, 2, 8, 0)); two.setOpaque(false); two.add(segmentCard); two.add(queryCard);
        input.add(two, BorderLayout.CENTER);
        addTool("+ Add Segment", this::addSegment, false); addTool("+ Add Query", this::addQuery, false);
        addRunButton(); setImportTarget(segments);
    }
    private void addSegment() { Vector<Object> row = new Vector<>(); row.add(segmentModel.getRowCount()); row.add(""); row.add(""); segmentModel.addRow(row); }
    private void addQuery() { Vector<Object> row = new Vector<>(); row.add("0"); row.add(""); queryModel.addRow(row); }
    @Override protected void loadSample(boolean large) {
        segmentModel.setRowCount(0); queryModel.setRowCount(0);
        int count = large ? 40 : 5;
        for (int i = 0; i < count; i++) {
            Vector<Object> row = new Vector<>(); row.add(i); row.add(i * 1200L); row.add(900 + (i % 5) * 100L); segmentModel.addRow(row);
        }
        int queryCount = large ? 55 : 5;
        for (int i = 0; i < queryCount; i++) {
            Vector<Object> row = new Vector<>(); row.add(i % count); row.add(i % 3 == 0 ? 1200 : 80 + i * 7); queryModel.addRow(row);
        }
    }
    @Override protected void clearData() { segmentModel.setRowCount(0); queryModel.setRowCount(0); output.setText(""); map.setSpans(List.of(), 1); }
    @Override protected JTable importTable() { return segments; }
    @Override protected void importData() {
        JTable target = chooseImportTable(List.of("Segment table", "Logical address queries"),
                List.of(segments, queries));
        if (target != null) importIntoTable(target);
    }
    @Override protected void runSimulation() {
        try {
            List<SegmentEntry> entries = new ArrayList<>();
            for (int i = 0; i < segmentModel.getRowCount(); i++)
                entries.add(new SegmentEntry(InputValidator.parseLong(cell(segments, i, 0, "Segment number"), "Segment number", 0, Long.MAX_VALUE),
                        InputValidator.parseLong(cell(segments, i, 1, "Base address"), "Base address", 0, Long.MAX_VALUE),
                        InputValidator.parseLong(cell(segments, i, 2, "Limit"), "Segment limit", 1, Long.MAX_VALUE)));
            List<SegmentQuery> requested = new ArrayList<>();
            for (int i = 0; i < queryModel.getRowCount(); i++)
                requested.add(new SegmentQuery(InputValidator.parseLong(cell(queries, i, 0, "Segment number"), "Segment number", 0, Long.MAX_VALUE),
                        InputValidator.parseLong(cell(queries, i, 1, "Offset"), "Offset", 0, Long.MAX_VALUE)));
            runTyped(() -> SegmentationAlgorithm.translate(entries, requested), results -> render(entries, results));
        } catch (Exception e) { showWarning(e); }
    }
    private void render(List<SegmentEntry> entries, List<SegmentResult> results) {
        StringBuilder text = new StringBuilder("Segment | Offset | Base | Limit | Physical address | Result\n");
        for (SegmentResult r : results) text.append(r.segment()).append(" | ").append(r.offset()).append(" | ")
                .append(r.base() == null ? "—" : r.base()).append(" | ").append(r.limit() == null ? "—" : r.limit())
                .append(" | ").append(r.physical() == null ? "—" : r.physical()).append(" | ").append(r.message()).append('\n');
        List<MemoryMapPanel.Span> spans = new ArrayList<>(); long total = 1;
        for (SegmentEntry entry : entries) total = Math.max(total, Math.addExact(entry.base(), entry.limit()));
        for (SegmentEntry entry : entries) spans.add(new MemoryMapPanel.Span("Seg " + entry.number(),
                entry.base(), entry.limit(), "limit " + entry.limit(), ModernTheme.INDIGO));
        map.setSpans(spans, total); showOutput(text.toString(), map);
    }
}
