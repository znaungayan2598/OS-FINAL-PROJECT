package com.ossimulator.utils;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** Helpers for pasting / importing large amounts of data (CSV, TXT, plain number lists). */
public final class BulkInput {
    private BulkInput() {}

    private static String clean(String text) {
        if (text == null) return "";
        return text.startsWith("﻿") ? text.substring(1) : text;
    }

    /** Splits on commas, semicolons, tabs, spaces and newlines. */
    public static List<String> tokens(String text) {
        List<String> out = new ArrayList<>();
        for (String t : clean(text).split("[\\s,;]+")) {
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    /** One list of tokens per non-empty line; lines starting with '#' are ignored. */
    public static List<List<String>> lines(String text, boolean skipHeader) {
        List<List<String>> rows = new ArrayList<>();
        boolean first = true;
        for (String line : clean(text).split("\\R")) {
            String t = line.trim();
            if (t.isEmpty() || t.startsWith("#")) continue;
            if (first && skipHeader) {
                first = false;
                continue;
            }
            first = false;
            List<String> cells = new ArrayList<>();
            for (String c : t.split("[,;\\t ]+")) {
                if (!c.isEmpty()) cells.add(c);
            }
            if (!cells.isEmpty()) rows.add(cells);
        }
        return rows;
    }

    public static String readFile(File f) throws IOException {
        return Files.readString(f.toPath(), StandardCharsets.UTF_8);
    }

    /** Shows an Open dialog restricted to .csv / .txt and returns the chosen file (or null). */
    public static File chooseFile(Component parent) {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Import CSV / TXT data");
        fc.setFileFilter(new FileNameExtensionFilter("CSV or text files (*.csv, *.txt)", "csv", "txt"));
        return fc.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION ? fc.getSelectedFile() : null;
    }
}
