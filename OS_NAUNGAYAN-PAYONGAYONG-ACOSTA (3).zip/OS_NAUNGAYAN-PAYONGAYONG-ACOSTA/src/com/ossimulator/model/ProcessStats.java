package com.ossimulator.model;

/** Per-process scheduling metrics. */
public record ProcessStats(String id, long arrival, long burst, int priority,
                           long completion, long turnaround, long waiting, long response) {
}
