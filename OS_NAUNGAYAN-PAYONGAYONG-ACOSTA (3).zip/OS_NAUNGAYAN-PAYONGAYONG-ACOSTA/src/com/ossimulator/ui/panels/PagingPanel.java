package com.ossimulator.ui.panels;

import com.ossimulator.algorithms.PagingAlgorithm;
import com.ossimulator.model.PagingRow;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/** Provides inputs and results for address translation. */
public final class PagingPanel extends ModulePanelBase {
    private final JTextField pageSize = textField("1024", 8), logicalPages = textField("6", 8), physicalFrames = textField("4", 8);
    private final DefaultTableModel pageModel = model(List.of("Page #", "Frame # (-1 = invalid)"));
    private final DefaultTableModel addressModel = model(List.of("Logical Address"));
    private final JTable pageTable = new JTable(pageModel), addressTable = new JTable(addressModel);
    public PagingPanel() {
        super("Paging", "Translate logical addresses using a configurable page table; invalid pages report faults.");
        JPanel config = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)); config.setOpaque(false);
        config.add(labelField("Page size (bytes)", pageSize)); config.add(labelField("Logical pages", logicalPages));
        config.add(labelField("Physical frames", physicalFrames));
        JPanel pages = cardPanel("Editable page table");
        pages.add(tableScroll(pageTable), BorderLayout.CENTER);
        pages.add(rowButtons(pageTable, "Page", this::addPage), BorderLayout.SOUTH);
        JPanel addresses = cardPanel("Logical addresses to translate");
        addresses.add(tableScroll(addressTable), BorderLayout.CENTER);
        addresses.add(rowButtons(addressTable, "Address", this::addAddress), BorderLayout.SOUTH);
        JPanel tables = new JPanel(new GridLayout(1, 2, 8, 0)); tables.setOpaque(false); tables.add(pages); tables.add(addresses);
        input.add(config, BorderLayout.NORTH); input.add(tables, BorderLayout.CENTER);
        setImportTarget(pageTable); addTool("Translate Addresses", this::runSimulation, true);
    }
    private void addPage() { Vector<Object> row = new Vector<>(); row.add(pageModel.getRowCount()); row.add("-1"); pageModel.addRow(row); }
    private void addAddress() { Vector<Object> row = new Vector<>(); row.add(""); addressModel.addRow(row); }
    private void fill(int count, boolean large) {
        pageModel.setRowCount(0); addressModel.setRowCount(0);
        for (int i = 0; i < count; i++) {
            Vector<Object> row = new Vector<>(); row.add(i); row.add(i < (large ? 9 : 4) ? i : -1); pageModel.addRow(row);
        }
        for (int i = 0; i < (large ? 80 : 5); i++) {
            Vector<Object> row = new Vector<>(); row.add(i * 500L + 17); addressModel.addRow(row);
        }
        logicalPages.setText(Integer.toString(count)); pageSize.setText("1024"); physicalFrames.setText(large ? "9" : "4");
    }
    @Override protected void loadSample(boolean large) { fill(large ? 35 : 5, large); }
    @Override protected void clearData() { pageModel.setRowCount(0); addressModel.setRowCount(0); output.setText(""); }
    @Override protected JTable importTable() { return pageTable; }
    @Override protected void importData() {
        JTable target = chooseImportTable(List.of("Page table", "Logical address queries"),
                List.of(pageTable, addressTable));
        if (target != null) importIntoTable(target);
    }
    @Override protected void runSimulation() {
        try {
            long size = InputValidator.parseLong(pageSize.getText(), "Page size", 1, Long.MAX_VALUE);
            int count = InputValidator.parseInt(logicalPages.getText(), "Logical pages", 1, Integer.MAX_VALUE);
            int frameCount = InputValidator.parseInt(physicalFrames.getText(), "Physical frames", 1, Integer.MAX_VALUE);
            Map<Long, Long> table = new HashMap<>();
            for (int i = 0; i < pageModel.getRowCount(); i++) {
                long page = InputValidator.parseLong(cell(pageTable, i, 0, "Page number"), "Page number", 0, count - 1L);
                long frame = InputValidator.parseLong(cell(pageTable, i, 1, "Frame number"), "Frame number", -1, Long.MAX_VALUE);
                if (frame >= frameCount) throw new InputValidator.InvalidInputException("Frame number must be -1 or less than the physical frame count.");
                if (table.put(page, frame) != null) throw new InputValidator.InvalidInputException("Page number " + page + " appears more than once in the page table.");
            }
            if (table.size() != count) throw new InputValidator.InvalidInputException("Page table row count must match Logical pages.");
            List<Long> frames = new ArrayList<>();
            for (long page = 0; page < count; page++) {
                if (!table.containsKey(page)) throw new InputValidator.InvalidInputException("Page table is missing logical page " + page + ".");
                frames.add(table.get(page));
            }
            List<Long> addresses = new ArrayList<>();
            for (int i = 0; i < addressModel.getRowCount(); i++)
                addresses.add(InputValidator.parseLong(cell(addressTable, i, 0, "Logical address"), "Logical address", 0, Long.MAX_VALUE));
            runTyped(() -> PagingAlgorithm.translate(size, count, frames, addresses), this::render);
        } catch (Exception e) { showWarning(e); }
    }
    private void render(List<PagingRow> results) {
        StringBuilder text = new StringBuilder("Logical | Page | Offset | Frame | Physical | Status\n");
        for (PagingRow row : results) text.append(row.logical()).append(" | ").append(row.page()).append(" | ")
                .append(row.offset()).append(" | ").append(row.frame() == null ? "—" : row.frame()).append(" | ")
                .append(row.physical() == null ? "—" : row.physical()).append(" | ").append(row.status()).append('\n');
        showOutput(text.toString());
    }
}
