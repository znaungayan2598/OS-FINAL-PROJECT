package com.ossimulator.algorithms;

import com.ossimulator.model.ReplacementResult;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Implements FIFO, LRU, and Optimal page replacement. */
public final class PageReplacement {
    private PageReplacement() {}
    /** Lists the supported disk scheduling algorithms. */
    public enum Algorithm { FIFO, LRU, OPTIMAL }

    public static ReplacementResult run(List<Integer> references, int frameCount, Algorithm algorithm) {
        if (references == null || references.isEmpty()) throw new IllegalArgumentException("Enter at least one page reference.");
        if (frameCount <= 0) throw new IllegalArgumentException("Frame count must be positive.");
        List<Integer> frames = new ArrayList<>();
        for (int i = 0; i < frameCount; i++) frames.add(null);
        List<List<Integer>> states = new ArrayList<>();
        List<Boolean> hits = new ArrayList<>();
        List<Integer> evicted = new ArrayList<>();
        int nextVictim = 0, hitCount = 0;
        List<Integer> lastUsed = new ArrayList<>();
        for (int i = 0; i < references.size(); i++) lastUsed.add(-1);
        for (int step = 0; step < references.size(); step++) {
            int page = references.get(step);
            if (page < 0) throw new IllegalArgumentException("Page references cannot be negative.");
            int slot = frames.indexOf(page);
            boolean hit = slot >= 0;
            Integer evictedPage = null;
            if (hit) {
                hitCount++;
                lastUsed.set(slot, step);
            } else {
                slot = frames.indexOf(null);
                if (slot < 0) {
                    if (algorithm == Algorithm.FIFO) {
                        slot = nextVictim;
                        nextVictim = (nextVictim + 1) % frameCount;
                    } else if (algorithm == Algorithm.LRU) {
                        slot = 0;
                        for (int f = 1; f < frameCount; f++) if (lastUsed.get(f) < lastUsed.get(slot)) slot = f;
                    } else {
                        slot = optimalVictim(references, step, frames);
                    }
                    evictedPage = frames.get(slot);
                }
                frames.set(slot, page);
                lastUsed.set(slot, step);
            }
            hits.add(hit);
            evicted.add(evictedPage);
            states.add(Collections.unmodifiableList(new ArrayList<>(frames)));
        }
        int faults = references.size() - hitCount;
        return new ReplacementResult(algorithm.name(), frameCount, List.copyOf(references),
                List.copyOf(states), List.copyOf(hits), Collections.unmodifiableList(new ArrayList<>(evicted)), hitCount, faults,
                100.0 * hitCount / references.size(), 100.0 * faults / references.size());
    }

    private static int optimalVictim(List<Integer> references, int step, List<Integer> frames) {
        int victim = 0, farthest = -1;
        for (int f = 0; f < frames.size(); f++) {
            int next = Integer.MAX_VALUE;
            for (int i = step + 1; i < references.size(); i++) {
                if (references.get(i).equals(frames.get(f))) { next = i; break; }
            }
            if (next > farthest) { farthest = next; victim = f; }
        }
        return victim;
    }
}
