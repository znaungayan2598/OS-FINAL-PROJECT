package com.ossimulator.model;

import java.util.List;

/** Output of a disk-scheduling run. */
public record DiskResult(String algorithm, List<Long> serviceOrder, List<DiskMove> moves,
                         long totalMovement, long head, long min, long max) {
}
