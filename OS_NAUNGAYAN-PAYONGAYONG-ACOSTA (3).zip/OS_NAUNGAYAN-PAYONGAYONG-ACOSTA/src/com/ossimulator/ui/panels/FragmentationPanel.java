package com.ossimulator.ui.panels;

import com.ossimulator.algorithms.FragmentationAlgorithm;
import com.ossimulator.model.FragProcess;
import com.ossimulator.model.FragResult;
import com.ossimulator.theme.ModernTheme;
import com.ossimulator.ui.components.MemoryMapPanel;
import com.ossimulator.utils.InputValidator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.HashSet;
import java.util.Set;

/** Provides inputs and results for memory allocation. */
public final class FragmentationPanel extends ModulePanelBase {
    private final DefaultTableModel blockModel = model(List.of("Block ID", "Size"));
    private final DefaultTableModel processModel = model(List.of("Process ID", "Memory Required"));
    private final JTable blocks = new JTable(blockModel), processes = new JTable(processModel);
    private final JComboBox<FragmentationAlgorithm.Strategy> strategy =
            new JComboBox<>(new Vector<>(List.of(FragmentationAlgorithm.Strategy.FIRST_FIT,
                    FragmentationAlgorithm.Strategy.BEST_FIT, FragmentationAlgorithm.Strategy.WORST_FIT)));
    private final MemoryMapPanel map = new MemoryMapPanel();
    public FragmentationPanel() {
        super("Fragmentation", "Allocate variable process requests into dynamic fixed partitions and inspect unused space.");
        JPanel blockCard = cardPanel("Memory blocks / partitions");
        blockCard.add(tableScroll(blocks), BorderLayout.CENTER);
        blockCard.add(rowButtons(blocks, "Block", this::addBlock), BorderLayout.SOUTH);
        JPanel processCard = cardPanel("Processes");
        processCard.add(tableScroll(processes), BorderLayout.CENTER);
        processCard.add(rowButtons(processes, "Process", this::addProcess), BorderLayout.SOUTH);
        JPanel tables = new JPanel(new GridLayout(1, 2, 8, 0)); tables.setOpaque(false); tables.add(blockCard); tables.add(processCard);
        JPanel options = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4)); options.setOpaque(false);
        options.add(labelField("Allocation strategy", strategy));
        JPanel body = new JPanel(new BorderLayout(8, 8)); body.setOpaque(false);
        body.add(options, BorderLayout.NORTH); body.add(tables, BorderLayout.CENTER);
        input.add(body, BorderLayout.CENTER);
        addTool("+ Add Block", this::addBlock, false); addTool("+ Add Process", this::addProcess, false);
        addRunButton(); setImportTarget(blocks);
    }
    private void addBlock() { Vector<Object> row = new Vector<>(); row.add("B" + blockModel.getRowCount()); row.add(""); blockModel.addRow(row); }
    private void addProcess() { Vector<Object> row = new Vector<>(); row.add("P" + processModel.getRowCount()); row.add(""); processModel.addRow(row); }
    @Override protected void loadSample(boolean large) {
        blockModel.setRowCount(0); processModel.setRowCount(0);
        int blockCount = large ? 42 : 5, processCount = large ? 48 : 5;
        for (int i = 0; i < blockCount; i++) {
            Vector<Object> row = new Vector<>(); row.add("B" + i); row.add(large ? 96 + (i * 47) % 400 : List.of(100, 500, 200, 300, 600).get(i)); blockModel.addRow(row);
        }
        for (int i = 0; i < processCount; i++) {
            Vector<Object> row = new Vector<>(); row.add("P" + i); row.add(large ? 30 + (i * 29) % 310 : List.of(212, 417, 112, 426, 60).get(i)); processModel.addRow(row);
        }
    }
    @Override protected void clearData() { blockModel.setRowCount(0); processModel.setRowCount(0); output.setText(""); map.setSpans(List.of(), 1); }
    @Override protected JTable importTable() { return blocks; }
    @Override protected void importData() {
        JTable target = chooseImportTable(List.of("Memory blocks", "Processes"),
                List.of(blocks, processes));
        if (target != null) importIntoTable(target);
    }
    @Override protected void runSimulation() {
        try {
            List<Long> sizes = new ArrayList<>();
            for (int i = 0; i < blockModel.getRowCount(); i++)
                sizes.add(InputValidator.parseLong(cell(blocks, i, 1, "Block size"), "Block size", 1, Long.MAX_VALUE));
            List<FragProcess> items = new ArrayList<>();
            Set<String> ids = new HashSet<>();
            for (int i = 0; i < processModel.getRowCount(); i++) {
                String id = cell(processes, i, 0, "Process ID");
                if (!ids.add(id)) throw new InputValidator.InvalidInputException("Process IDs must be unique: " + id + ".");
                items.add(new FragProcess(id,
                        InputValidator.parseLong(cell(processes, i, 1, "Process memory"), "Process memory", 1, Long.MAX_VALUE)));
            }
            FragmentationAlgorithm.Strategy selected = (FragmentationAlgorithm.Strategy) strategy.getSelectedItem();
            runTyped(() -> FragmentationAlgorithm.run(sizes, items, selected), this::render);
        } catch (Exception e) { showWarning(e); }
    }
    private void render(FragResult result) {
        StringBuilder text = new StringBuilder("Strategy: ").append(result.strategy()).append("\n\nProcess | Required | Block | Status\n");
        for (int i = 0; i < result.processes().size(); i++) {
            int block = result.allocation().get(i);
            text.append(result.processes().get(i).id()).append(" | ").append(result.processes().get(i).size()).append(" | ")
                    .append(block < 0 ? "—" : "B" + block).append(" | ").append(block < 0 ? "Unallocated" : "Allocated").append('\n');
        }
        text.append("\nTotal internal fragmentation: ").append(result.internalFrag())
                .append("\nTotal external/free space: ").append(result.externalFrag())
                .append("\nAllocated: ").append(result.allocatedCount()).append(" / ").append(result.processes().size())
                .append("\nUnallocated: ").append(result.unallocatedCount());
        List<MemoryMapPanel.Span> spans = new ArrayList<>(); long position = 0, total = 0;
        for (int i = 0; i < result.blocks().size(); i++) {
            long size = result.blocks().get(i).size(); total = Math.addExact(total, size);
            int processIndex = result.allocation().indexOf(i);
            String label = processIndex < 0 ? "B" + i + " FREE" : "B" + i + " → " + result.processes().get(processIndex).id();
            String detail = processIndex < 0 ? "free " + size : "internal " + (size - result.processes().get(processIndex).size());
            Color color = processIndex < 0 ? ModernTheme.IDLE : Color.getHSBColor((i * .17f) % 1, .6f, .8f);
            spans.add(new MemoryMapPanel.Span(label, position, size, detail, color)); position += size;
        }
        map.setSpans(spans, Math.max(1, total)); showOutput(text.toString(), map);
    }
}
