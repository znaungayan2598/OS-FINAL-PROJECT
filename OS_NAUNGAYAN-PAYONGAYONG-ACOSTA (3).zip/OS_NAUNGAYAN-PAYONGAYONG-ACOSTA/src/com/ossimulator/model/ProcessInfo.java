package com.ossimulator.model;

/** One CPU-scheduling input row. A lower priority number means a higher priority. */
public record ProcessInfo(String id, long arrival, long burst, int priority) {
}
